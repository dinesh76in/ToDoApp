package com.db.lmui.repository;

import java.util.Hashtable;

import javax.naming.Context;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;

public class LDAPAuth {
	
	private String distinguishedName;

	public static void main(String[] args) {
		
		String distinguishedName="uid=Single_Client_View,ou=Directory Administrators,dc=dbgroup, dc=com";
		String password="Root$123";
		
		System.out.println(new LDAPAuth().authenticate(distinguishedName,password));
	}

	public boolean authenticate(String user, String password) {
		
		Hashtable<String, String> authEnv = new Hashtable<String, String>();
		authEnv.put(Context.INITIAL_CONTEXT_FACTORY,"com.sun.jndi.ldap.LdapCtxFactory");
		authEnv.put(Context.PROVIDER_URL, "ldap://ldapd2.uk.db.com:389");
		authEnv.put(Context.SECURITY_AUTHENTICATION, "simple");
		authEnv.put(Context.SECURITY_PRINCIPAL, user);
		authEnv.put(Context.SECURITY_CREDENTIALS, password);

		
		System.out.println("  ******* Invoking LDAP Authentication for User ********* "+user);
		try {
			DirContext authContext = new InitialDirContext(authEnv);
			System.out.println(" Authentication Successful for User " + user);
			return true;

		} catch (Exception e) {
		System.out.println("  Authentication FAILED for User "+ user);
			e.printStackTrace();
			return false;
		}
	}
	
	private static String convertUserIdToCommanName(String user){
		return user.replace("."," ");
		
	}
	
/*	private static String getLdapbase(){
		return user.replace("."," ");
		
	}*/


}
