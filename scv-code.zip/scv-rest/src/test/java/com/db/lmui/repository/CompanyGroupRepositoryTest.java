/*package com.db.lmui.repository;

import java.util.List;

import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.db.lmui.mapper.CompanyGroupMapper;
import com.db.lmui.model.CompanyGroup;

@Ignore
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:applicationContext.xml" })
public class CompanyGroupRepositoryTest {
	
	@Autowired
	private CompanyGroupMapper companyGroupMapper = null;

	@Test
	public void testCreateAccount() throws Exception {
		List<CompanyGroup> companyGroups = companyGroupMapper.getAll();
		
		for (CompanyGroup companyGroup : companyGroups) {
			System.out.println(companyGroup.toString());
		}

		System.out.println("===========Number of Clients ============"+companyGroups.size());
	    Assert.assertEquals(true, companyGroups.size()>0);
	}
}
*/