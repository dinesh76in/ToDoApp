package com.db.lmui.repository;


import java.util.Hashtable;

import javax.naming.Context;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;


public class LDAPAuthenticator {
	private String ldapurl;
	private String ldapbase;
	private String distinguishedName;

	public String getLdapurl() {
		return ldapurl;
	}

	public void setLdapurl(String ldapurl) {
		this.ldapurl = ldapurl;
	}

	public String getLdapbase() {
		return ldapbase;
	}

	public void setLdapbase(String ldapbase) {
		this.ldapbase = ldapbase;
	}

	public String getDistinguishedName() {
		return distinguishedName;
	}

	public void setDistinguishedName(String distinguishedName) {
		this.distinguishedName = distinguishedName;
	}

	public boolean authenticate(String user, String password) {

		distinguishedName = "cn=" + convertUserIdToCommanName(user) + "," + getLdapbase();
		Hashtable<String, String> authEnv = new Hashtable<String, String>();
		authEnv.put(Context.INITIAL_CONTEXT_FACTORY,
				"com.sun.jndi.ldap.LdapCtxFactory");
		authEnv.put(Context.PROVIDER_URL, getLdapurl());
		authEnv.put(Context.SECURITY_AUTHENTICATION, "simple");
		authEnv.put(Context.SECURITY_PRINCIPAL, "Single_Client_View,ou=Directory Administrators,dc=dbgroup, dc=com");
		authEnv.put(Context.SECURITY_CREDENTIALS, "rIl68FtK");

		
		System.out.println("  ******* Invoking LDAP Authentication for User ********* "+user);
		try {
			DirContext authContext = new InitialDirContext(authEnv);
			System.out.println(" Authentication Successful for User " + user);
			return true;

		} catch (Exception e) {
		System.out.println("  Authentication FAILED for User "+ user);
			e.printStackTrace();
			return false;

		}
	}
	
	
	private static String convertUserIdToCommanName(String user){
		return user.replace("."," ");
		
	}
	
	
	/*
	public static void main(String args[]){
		System.out.println(convertUserIdToCommanName("Dinesh.Verma"));
		
	}*/


}
