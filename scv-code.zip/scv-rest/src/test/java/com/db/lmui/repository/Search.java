package com.db.lmui.repository;

import java.util.*;
import javax.naming.*;
import javax.naming.directory.*;
import javax.naming.ldap.*;

public class Search {

  public static void main(String[] args) throws Exception {

    // the root of the DB LDAP 'people' tree from where we will start our searches
    String searchBase = "ou=people,ou=global,dc=dbgroup,dc=com";

    // your LDAP credentials
                     
    
    String ldapbase="OU=Users,OU=users,DC=dbgroup,DC=com";
    String bindDN =  "uid=vermdin,ou=users,dc=dbgroup,dc=com";
    String bindPWD = "Cool*123";

    // the LDAP server connection details
    // Note: multiple addresses can be supplied - RECOMMENDED!)
    String url = " ldap://ldapep1.uk.db.com:389";    // server URLs, e.g. "ldap://ldapb1.uk.db.com ldap://ldapus1.us.db.com"

    // create the environment and then the context
    Hashtable env = new Hashtable();
    env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
    env.put(Context.SECURITY_AUTHENTICATION, "simple");
    env.put(Context.SECURITY_PRINCIPAL, bindDN);  // the distinguished name (DN) of the application
    env.put(Context.SECURITY_CREDENTIALS, bindPWD);  // the application password
    env.put(Context.PROVIDER_URL, url);    // the LDAP URL
    DirContext context = new InitialDirContext(env);

    // define the search controls
    SearchControls controls = new SearchControls();

    // set the search scope. Can be one of OBJECT_SCOPE, ONELEVEL_SCOPE
    // or SUBTREE_SCOPE. All people are stored at the same level, so
    // ONELEVEL_SCOPE is used
    controls.setSearchScope(SearchControls.ONELEVEL_SCOPE);

    // specify the attributes to return. If we don't do this all
    // atrributes will be retuned.
    String[] attrs = { "givenname", "sn", "telephonenumber" };
    controls.setReturningAttributes(attrs);

    // do the search
    String searchFilter = "(mail=" + args[0] + ")";
    NamingEnumeration results = context.search(searchBase, searchFilter, controls);

    // iterate through the results set
    while (results.hasMore()) {
      SearchResult sresult = (SearchResult)results.next();

      // get all of the attributes returned.
      Attributes attributes = sresult.getAttributes();
      System.out.println(attributes);
    }
  }
}
