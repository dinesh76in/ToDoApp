package com.db.scv.model;

public class ProcessControl {

	private String codeProcess;
	private String typeCode;
	private String language;
	private Integer execDate;
	private Integer lastDate;
	private Integer nextDate;
	private String statusProcess;
	private Integer orderProcess;
	private String restartKey;
	private Integer dataVersionNo;
	private String changeTimeStamp;
	private String changeUserId;
	private String changeMsgCarrierId;
	private String changeCountry;
	private Integer changeEntity;
	private Integer changeBranch;

	public String getCodeProcess() {
		return codeProcess;
	}

	public void setCodeProcess(String codeProcess) {
		this.codeProcess = codeProcess;
	}

	public String getTypeCode() {
		return typeCode;
	}

	public void setTypeCode(String typeCode) {
		this.typeCode = typeCode;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	public Integer getExecDate() {
		return execDate;
	}

	public void setExecDate(Integer execDate) {
		this.execDate = execDate;
	}

	public Integer getLastDate() {
		return lastDate;
	}

	public void setLastDate(Integer lastDate) {
		this.lastDate = lastDate;
	}

	public Integer getNextDate() {
		return nextDate;
	}

	public void setNextDate(Integer nextDate) {
		this.nextDate = nextDate;
	}

	public String getStatusProcess() {
		return statusProcess;
	}

	public void setStatusProcess(String statusProcess) {
		this.statusProcess = statusProcess;
	}

	public Integer getOrderProcess() {
		return orderProcess;
	}

	public void setOrderProcess(Integer orderProcess) {
		this.orderProcess = orderProcess;
	}

	public String getRestartKey() {
		return restartKey;
	}

	public void setRestartKey(String restartKey) {
		this.restartKey = restartKey;
	}

	public Integer getDataVersionNo() {
		return dataVersionNo;
	}

	public void setDataVersionNo(Integer dataVersionNo) {
		this.dataVersionNo = dataVersionNo;
	}

	public String getChangeTimeStamp() {
		return changeTimeStamp;
	}

	public void setChangeTimeStamp(String changeTimeStamp) {
		this.changeTimeStamp = changeTimeStamp;
	}

	public String getChangeUserId() {
		return changeUserId;
	}

	public void setChangeUserId(String changeUserId) {
		this.changeUserId = changeUserId;
	}

	public String getChangeMsgCarrierId() {
		return changeMsgCarrierId;
	}

	public void setChangeMsgCarrierId(String changeMsgCarrierId) {
		this.changeMsgCarrierId = changeMsgCarrierId;
	}

	public String getChangeCountry() {
		return changeCountry;
	}

	public void setChangeCountry(String changeCountry) {
		this.changeCountry = changeCountry;
	}

	public Integer getChangeEntity() {
		return changeEntity;
	}

	public void setChangeEntity(Integer changeEntity) {
		this.changeEntity = changeEntity;
	}

	public Integer getChangeBranch() {
		return changeBranch;
	}

	public void setChangeBranch(Integer changeBranch) {
		this.changeBranch = changeBranch;
	}

}
