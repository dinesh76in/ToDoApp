package com.db.scv.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.db.scv.mapper.cpe.BalanceMapper;
import com.db.scv.mapper.cpe.ProcessControlMapper;
import com.db.scv.model.Account;
import com.db.scv.model.Balance;
import com.db.scv.service.AccountService;
import com.db.scv.service.BalanceService;
import com.db.scv.util.AppUtil;

@Component
@Service
public class BalanceServiceImpl implements BalanceService {

	private static final Logger LOG = LoggerFactory.getLogger(BalanceServiceImpl.class);

	@Autowired
	private BalanceMapper balanceMapper = null;

	@Autowired
	private AccountService accountService = null;

	@Autowired
	private ProcessControlMapper processControlMapper = null;

	@Override
	public List<Balance> getBalance(String[] mt940AccIds, Integer balanceDate, String action) {

		LOG.info("Fetching client account balances for accounts:" + mt940AccIds + " balanceDate:" + balanceDate);

		int valueDate = 0;
		
		if(balanceDate==0){
			balanceDate=processControlMapper.getExecDate();
		}

		if (action.equalsIgnoreCase("current")) {
			valueDate = processControlMapper.getExecDate();
		} else if (action.equalsIgnoreCase("next")) {
			valueDate = AppUtil.getNextDate(balanceDate, "next");
		} else if (action.equalsIgnoreCase("prev")) {
			valueDate = AppUtil.getNextDate(balanceDate, action);
		} else {
			valueDate = processControlMapper.getExecDate();
		}
		
		List<Balance> balances=balanceMapper.getBalance(mt940AccIds, valueDate, 0, 0);

		int execDate=processControlMapper.getExecDate();
		balances.forEach(balance->balance.setExecDate(execDate));
		
		return balances;
	}

	
	@Override
	public List<Balance> getCashGroupAccountBalances(String groupSname,Integer groupSequence,  Integer balanceDate,
			String action) {

		LOG.info("Fetching pool account balances for groupSname:" + groupSname + " groupSequence:" + groupSequence
				+ " balanceDate:" + balanceDate);

		List<Account> cashGroupAccounts = accountService.getCashGroupAccounts(groupSname, groupSequence);
	
		int valueDate = 0;
		
		if(balanceDate==0){
			balanceDate=processControlMapper.getExecDate();
		}
 
		if (action.equalsIgnoreCase("current")) {
			valueDate = processControlMapper.getExecDate();
		} else if (action.equalsIgnoreCase("next")) {
			valueDate = AppUtil.getNextDate(balanceDate, "next");
		} else if (action.equalsIgnoreCase("prev")) {
			valueDate = AppUtil.getNextDate(balanceDate, action);
		} else {
			valueDate = processControlMapper.getExecDate();
		}

		List<Balance> balances = balanceMapper.getBalance(extractAccountIds(cashGroupAccounts), valueDate, 0, 0);
	
		
		int execDate=processControlMapper.getExecDate();
		
		balances.forEach(balance->balance.setExecDate(execDate));
		
		return balances;
	}


	@Override
	public List<Balance> getBalance(String[] mt940AccIds, Integer fromDate, Integer toDate) {
		return balanceMapper.getBalance(mt940AccIds, 0, fromDate, toDate);
	}
	

	private String[] extractAccountIds(List<Account> accounts) {
		return accounts.stream().map(Account::getMt940AcId).collect(Collectors.toList()).toArray(new String[accounts.size()]);
	}
	
}
