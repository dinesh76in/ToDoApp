package com.db.scv.service.impl;

import java.util.Hashtable;

import javax.naming.Context;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.db.scv.model.ScvUser;
import com.db.scv.service.AuthService;

@Component
@Service
public class AuthServiceImpl implements AuthService {
	
	private static final Logger LOG = LoggerFactory.getLogger(AuthServiceImpl.class);

	private ScvUser scvUser;
	private static final String DN_SUFFIX="ou=Directory Administrators,dc=dbgroup, dc=com";
	
	public ScvUser authenticate(String userId, String password) {
		scvUser=new ScvUser();
		scvUser.setUserId(userId);
		String userDN=getUserDN(userId);

		Hashtable<String, String> authEnv = new Hashtable<String, String>();
		authEnv.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
		authEnv.put(Context.PROVIDER_URL, "ldap://ldapd2.uk.db.com:389");
		authEnv.put(Context.SECURITY_AUTHENTICATION, "simple");
		authEnv.put(Context.SECURITY_PRINCIPAL,userDN);
		authEnv.put(Context.SECURITY_CREDENTIALS, password);

		LOG.info("  ******* Invoking LDAP Authentication for User DN ********* " + userDN);
		try {
			DirContext authContext = new InitialDirContext(authEnv);
		
			LOG.info(" Authentication Successful for User DN " + userDN);
			scvUser.setAuthenticated(true);
			return scvUser;
			} catch (Exception e) {
				LOG.error("  Authentication FAILED for userDN " + userDN,e);
			scvUser.setAuthenticated(false);
			return scvUser;
		}
	}

	private String getUserDN(String userId) {
		return "uid="+userId+","+DN_SUFFIX;
	}

}
