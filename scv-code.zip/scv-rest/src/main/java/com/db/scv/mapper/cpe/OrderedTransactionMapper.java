package com.db.scv.mapper.cpe;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.SelectProvider;

import com.db.scv.mapper.provider.TransactionSelectProvider;
import com.db.scv.model.OrderedTransaction;

public interface OrderedTransactionMapper {
	
	@SelectProvider(type = TransactionSelectProvider.class, method = "getTransactions")
      @Results(value = {
    	      @Result(property = "orderIdentifier", column = "ORDER_IDENTIFIER"),
    	      @Result(property = "sourceMt940Acc", column = "SOURCE_MT940_ACC"),
    	      @Result(property = "targetMt940Acc", column = "TARGET_MT940_ACC"),
    	      @Result(property = "currencyCode", column = "CURRENCY_CODE"),       
    	      @Result(property = "amount", column = "AMOUNT"),
    	      @Result(property = "sourceExecDate", column = "SOURCE_EXEC_DATE"),
    	      @Result(property = "sourceValueDate", column = "SOURCE_VALUE_DATE"),
    	      @Result(property = "targetExecDate", column = "TARGET_EXEC_DATE"),
    	      @Result(property = "targetValueDate", column = "TARGET_VALUE_DATE"),
    	      @Result(property = "paymentDetails1", column = "PAYMENT_DETAILS1"),       
    	      @Result(property = "paymentDetails2", column = "PAYMENT_DETAILS2"),
    	      @Result(property = "paymentDetails3", column = "PAYMENT_DETAILS3"),
    	      @Result(property = "ordStatus", column = "ORD_STATUS"),
    	      @Result(property = "ordStatusDate", column = "ORD_STATUS_DATE"),       
    	      @Result(property = "balanceSource", column = "BALANCE_SOURCE"),
    	      @Result(property = "balanceTarget", column = "BALANCE_TARGET"),
    	      @Result(property = "plannedTrnId", column = "PLANNED_TRN_ID"),       
    	      @Result(property = "groupSequence", column = "GROUP_SEQUENCE"),
    	      @Result(property = "rulSequence", column = "RUL_SEQUENCE"),       
    	      @Result(property = "dataVersionNo", column = "DATA_VERSION_NO"),
    	      @Result(property = "changeTimeStamp", column = "CHANGE_TS"), 
    	      @Result(property = "changeUserId", column = "CHANGE_USERID"),
    	      @Result(property = "changeMsgCarrierId", column = "CHG_MESS_CARR_ID"), 
    	      @Result(property = "changeCountry", column = "CHANGE_COUNTRY"),
    	      @Result(property = "changeEntity", column = "CHANGE_ENTITY"),
    	      @Result(property = "changeBranch", column = "CHANGE_BRANCH"),
    	      @Result(property = "insertDate", column = "INSERT_DATE"),
    	      @Result(property = "deleteDate", column = "DELETE_DATE"),
    	      @Result(property = "orderIdentOrig", column = "ORDER_IDENT_ORIG"),       
    	      @Result(property = "entity", column = "ENTITY"),
    	      @Result(property = "flags", column = "FLAGS"),       
    	      @Result(property = "procBranch", column = "PROC_BRANCH"),
    	      @Result(property = "productSeq", column = "PRODUCT_SEQ"),
    	      @Result(property = "changeSequence", column = "CHANGE_SEQUENCE")
    	   })
	  public List<OrderedTransaction> getTransactions(@Param("mt940AccIds") String[] mt940AccIds);
 
}
