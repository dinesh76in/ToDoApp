package com.db.scv.mapper.cpe;

import java.util.List;

import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;

import com.db.scv.model.CompanyGroup;

public interface CompanyGroupMapper {
	
	@Select("SELECT * FROM PZ004T where delete_date=0")
	   @Results(value = {
	      @Result(property = "groupSname", column = "GROUP_SNAME"),
	      @Result(property = "groupLname", column = "GROUP_LNAME"),
	      @Result(property = "gamName", column = "GAM_NAME"),
	      @Result(property = "gamPhone", column = "GAM_PHONE"),       
	      @Result(property = "gamFax", column = "GAM_FAX"),
	      @Result(property = "gamEmail", column = "GAM_EMAIL"),
	      @Result(property = "gamLanguage", column = "GAM_LANGUAGE"),
	      @Result(property = "treasureName", column = "TREASURE_NAME"),
	      @Result(property = "treasurePhone", column = "TREASURE_PHONE"),
	      @Result(property = "treasureFax", column = "TREASURE_FAX"),       
	      @Result(property = "treasureEmail", column = "TREASURE_EMAIL"),
	      @Result(property = "treasureLanguage", column = "TREASURE_LANGUAGE"),
	      @Result(property = "currencyCode", column = "CURRENCY_CODE"),
	      @Result(property = "countryCode", column = "COUNTRY_CODE"),
	      @Result(property = "insertDate", column = "INSERT_DATE"),       
	      @Result(property = "deleteDate", column = "DELETE_DATE"),
	      @Result(property = "dataVersionNo", column = "DATA_VERSION_NO"),
	     // @Result(property = "changeTimestamp", column = "CHANGE_TS"),
	      @Result(property = "changeUserId", column = "CHANGE_USERID"),
	      @Result(property = "changeMsgCarrierId", column = "CHG_MESS_CARR_ID"),       
	      @Result(property = "changeCountry", column = "CHANGE_COUNTRY"),
	      @Result(property = "changeEntity", column = "CHANGE_ENTITY"),
	      @Result(property = "changeBranch", column = "CHANGE_BRANCH"),
	      @Result(property = "changeSequence", column = "CHANGE_SEQUENCE"),
	      @Result(property = "businessUnit", column = "BUSINESS_UNIT"),
	      @Result(property = "timeDif", column = "TIME_DIF"),       
	      @Result(property = "entity", column = "ENTITY"),
	      @Result(property = "ediPrisma", column = "EDI_PRISMA")
	   })
	  public List<CompanyGroup> getAll();

      @Select("Select * from Pz004T where group_sname like '%'||#{groupSname}||'%' and rownum=1 and delete_date=0")
      @Results(value = {
    	      @Result(property = "groupSname", column = "GROUP_SNAME"),
    	      @Result(property = "groupLname", column = "GROUP_LNAME"),
    	      @Result(property = "gamName", column = "GAM_NAME"),
    	      @Result(property = "gamPhone", column = "GAM_PHONE"),       
    	      @Result(property = "gamFax", column = "GAM_FAX"),
    	      @Result(property = "gamEmail", column = "GAM_EMAIL"),
    	      @Result(property = "gamLanguage", column = "GAM_LANGUAGE"),
    	      @Result(property = "treasureName", column = "TREASURE_NAME"),
    	      @Result(property = "treasurePhone", column = "TREASURE_PHONE"),
    	      @Result(property = "treasureFax", column = "TREASURE_FAX"),       
    	      @Result(property = "treasureEmail", column = "TREASURE_EMAIL"),
    	      @Result(property = "treasureLanguage", column = "TREASURE_LANGUAGE"),
    	      @Result(property = "currencyCode", column = "CURRENCY_CODE"),
    	      @Result(property = "countryCode", column = "COUNTRY_CODE"),
    	      @Result(property = "insertDate", column = "INSERT_DATE"),       
    	      @Result(property = "deleteDate", column = "DELETE_DATE"),
    	      @Result(property = "dataVersionNo", column = "DATA_VERSION_NO"),
    	     /* @Result(property = "changeTimestamp", column = "CHANGE_TS"),*/
    	      @Result(property = "changeUserId", column = "CHANGE_USERID"),
    	      @Result(property = "changeMsgCarrierId", column = "CHG_MESS_CARR_ID"),       
    	      @Result(property = "changeCountry", column = "CHANGE_COUNTRY"),
    	      @Result(property = "changeEntity", column = "CHANGE_ENTITY"),
    	      @Result(property = "changeBranch", column = "CHANGE_BRANCH"),
    	      @Result(property = "changeSequence", column = "CHANGE_SEQUENCE"),
    	      @Result(property = "businessUnit", column = "BUSINESS_UNIT"),
    	      @Result(property = "timeDif", column = "TIME_DIF"),       
    	      @Result(property = "entity", column = "ENTITY"),
    	      @Result(property = "ediPrisma", column = "EDI_PRISMA")
    	   })
	  public CompanyGroup getCompanyGroup(String groupSname);
      
      
      @Select("Select * from Pz004T where lower(group_sname) like lower('%'||#{searchStr}||'%') and delete_date=0")
      @Results(value = {
    	      @Result(property = "groupSname", column = "GROUP_SNAME"),
    	      @Result(property = "groupLname", column = "GROUP_LNAME"),
    	      @Result(property = "gamName", column = "GAM_NAME"),
    	      @Result(property = "gamPhone", column = "GAM_PHONE"),       
    	      @Result(property = "gamFax", column = "GAM_FAX"),
    	      @Result(property = "gamEmail", column = "GAM_EMAIL"),
    	      @Result(property = "gamLanguage", column = "GAM_LANGUAGE"),
    	      @Result(property = "treasureName", column = "TREASURE_NAME"),
    	      @Result(property = "treasurePhone", column = "TREASURE_PHONE"),
    	      @Result(property = "treasureFax", column = "TREASURE_FAX"),       
    	      @Result(property = "treasureEmail", column = "TREASURE_EMAIL"),
    	      @Result(property = "treasureLanguage", column = "TREASURE_LANGUAGE"),
    	      @Result(property = "currencyCode", column = "CURRENCY_CODE"),
    	      @Result(property = "countryCode", column = "COUNTRY_CODE"),
    	      @Result(property = "insertDate", column = "INSERT_DATE"),       
    	      @Result(property = "deleteDate", column = "DELETE_DATE"),
    	      @Result(property = "dataVersionNo", column = "DATA_VERSION_NO"),
    	      @Result(property = "changeTimestamp", column = "CHANGE_TS"),
    	      @Result(property = "changeUserId", column = "CHANGE_USERID"),
    	      @Result(property = "changeMsgCarrierId", column = "CHG_MESS_CARR_ID"),       
    	      @Result(property = "changeCountry", column = "CHANGE_COUNTRY"),
    	      @Result(property = "changeEntity", column = "CHANGE_ENTITY"),
    	      @Result(property = "changeBranch", column = "CHANGE_BRANCH"),
    	      @Result(property = "changeSequence", column = "CHANGE_SEQUENCE"),
    	      @Result(property = "businessUnit", column = "BUSINESS_UNIT"),
    	      @Result(property = "timeDif", column = "TIME_DIF"),       
    	      @Result(property = "entity", column = "ENTITY"),
    	      @Result(property = "ediPrisma", column = "EDI_PRISMA")
    	   })
	  public List<CompanyGroup> searchClient(String searchStr);
        
    
}
