package com.db.scv.model;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

public class ScvUser {
	
	public  String userId;
	private boolean authenticated;
	private String userGroup;
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public boolean isAuthenticated() {
		return authenticated;
	}
	public void setAuthenticated(boolean authenticated) {
		this.authenticated = authenticated;
	}
	public String getUserGroup() {
		return userGroup;
	}
	public void setUserGroup(String userGroup) {
		this.userGroup = userGroup;
	}
	
	public String toString(){
		return ReflectionToStringBuilder.toString(this);

	}

	
}
