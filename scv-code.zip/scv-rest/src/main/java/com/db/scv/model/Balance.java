package com.db.scv.model;

import java.math.BigDecimal;


public class Balance {
	
	private Integer valueDate;
	private String mt940Acid;
	private BigDecimal balanceDayNet;
	private BigDecimal balanceDayCr;
	private BigDecimal balanceDayDb;
	private BigDecimal balanceRealNet;
	private BigDecimal balanceRealCr;
	private BigDecimal balanceRealDb;
	private BigDecimal bookBalance;
	private String currencyCode;
	private Integer dataVersionNo;
	private String  changeTimeStamp;
	private String changeUserId;
	private String changeMsgCarrierId;
	private String changeCountry;
	private Integer changeEntity;
	private Integer changeBranch;
	private Integer execDate;
	
	public  Integer getValueDate() {
		return valueDate;
	}
	public void setValueDate(Integer valueDate) {
		this.valueDate = valueDate;
	}
	public String getMt940Acid() {
		return mt940Acid;
	}
	public void setMt940Acid(String mt940Acid) {
		this.mt940Acid = mt940Acid;
	}
	public BigDecimal getBalanceDayNet() {
		return balanceDayNet;
	}
	public void setBalanceDayNet(BigDecimal balanceDayNet) {
		this.balanceDayNet = balanceDayNet;
	}
	public BigDecimal getBalanceDayCr() {
		return balanceDayCr;
	}
	public void setBalanceDayCr(BigDecimal balanceDayCr) {
		this.balanceDayCr = balanceDayCr;
	}
	public BigDecimal getBalanceDayDb() {
		return balanceDayDb;
	}
	public void setBalanceDayDb(BigDecimal balanceDayDb) {
		this.balanceDayDb = balanceDayDb;
	}
	public BigDecimal getBalanceRealNet() {
		return balanceRealNet;
	}
	public void setBalanceRealNet(BigDecimal balanceRealNet) {
		this.balanceRealNet = balanceRealNet;
	}
	public BigDecimal getBalanceRealCr() {
		return balanceRealCr;
	}
	public void setBalanceRealCr(BigDecimal balanceRealCr) {
		this.balanceRealCr = balanceRealCr;
	}
	public BigDecimal getBalanceRealDb() {
		return balanceRealDb;
	}
	public void setBalanceRealDb(BigDecimal balanceRealDb) {
		this.balanceRealDb = balanceRealDb;
	}
	public BigDecimal getBookBalance() {
		return bookBalance;
	}
	public void setBookBalance(BigDecimal bookBalance) {
		this.bookBalance = bookBalance;
	}
	public String getCurrencyCode() {
		return currencyCode;
	}
	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}
	public Integer getDataVersionNo() {
		return dataVersionNo;
	}
	public void setDataVersionNo(Integer dataVersionNo) {
		this.dataVersionNo = dataVersionNo;
	}
	public String getChangeTimeStamp() {
		return changeTimeStamp;
	}
	public void setChangeTimeStamp(String changeTimeStamp) {
		this.changeTimeStamp = changeTimeStamp;
	}
	public String getChangeUserId() {
		return changeUserId;
	}
	public void setChangeUserId(String changeUserId) {
		this.changeUserId = changeUserId;
	}
	public String getChangeMsgCarrierId() {
		return changeMsgCarrierId;
	}
	public void setChangeMsgCarrierId(String changeMsgCarrierId) {
		this.changeMsgCarrierId = changeMsgCarrierId;
	}
	public String getChangeCountry() {
		return changeCountry;
	}
	public void setChangeCountry(String changeCountry) {
		this.changeCountry = changeCountry;
	}
	public Integer getChangeEntity() {
		return changeEntity;
	}
	public void setChangeEntity(Integer changeEntity) {
		this.changeEntity = changeEntity;
	}
	
	public Integer getChangeBranch() {
		return changeBranch;
	}
	public void setChangeBranch(Integer changeBranch) {
		this.changeBranch = changeBranch;
	}
	public Integer getExecDate() {
		return execDate;
	}
	public void setExecDate(Integer execDate) {
		this.execDate = execDate;
	}

}
