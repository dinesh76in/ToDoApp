package com.db.scv.resource;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.GenericEntity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.db.scv.model.Company;
import com.db.scv.service.CompanyService;


@Path("/company")
@Component
public class CompanyResource {


	private static final Logger LOG = LoggerFactory.getLogger(CompanyResource.class);

	@Autowired
	private CompanyService companyService = null;

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/client/{groupSname}")
	public Response getClientLegalEntities(@PathParam("groupSname")String groupSname) {
		LOG.info(" Fetching legalEntities for client "+groupSname);
		List<Company> legalEntities = companyService.getClientCompanies(groupSname);

		LOG.info(" Number of legalEntities  fetched -  " + legalEntities.size());
		GenericEntity<List<Company>> ge = new GenericEntity<List<Company>>(legalEntities) {};
		return Response.ok(ge).build();
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
    @Path("{cmpnySname}")
	public Response getCompany(@PathParam("cmpnySname")String cmpnySname) {
		LOG.info(" Fetching accounts for company  "+cmpnySname);
		Company company = companyService.getCompany(cmpnySname);

		GenericEntity<Company> ge = new GenericEntity<Company>(company) {};
		return Response.ok(ge).build();
	}

}
