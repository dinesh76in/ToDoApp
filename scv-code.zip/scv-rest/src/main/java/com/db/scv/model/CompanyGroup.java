package com.db.scv.model;

import java.io.Serializable;
import java.sql.Timestamp;
import javax.xml.bind.annotation.XmlRootElement;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

@XmlRootElement(name = "CompanyGroup")
public class CompanyGroup implements Serializable{

	private static final long serialVersionUID = -3155967058607434327L;
	private String groupSname;
	private String groupLname;
	private String gamName;
	private String gamPhone;
	private String gamFax;
	private String gamEmail;
	private String gamLanguage;
	private String treasureName;
	private String treasurePhone;
	private String treasureFax;
	private String treasureEmail;
	private String treasureLanguage;
	private String currencyCode;
	private String countryCode;
	private Integer insertDate;
	private Integer deleteDate;
	private Integer dataVersionNo;
	//private Timestamp changeTimestamp;
	private String changeUserId;
	private String changeMsgCarrierId;
	private String changeCountry;
	private String changeEntity;
	private String changeBranch;
	private String businessUnit;
	private Integer changeSequence;
	private String timeDif;
	private String entity;
	private String ediPrisma;

	public String getGroupSname() {
		return groupSname;
	}
	public void setGroupSname(String groupSname) {
		this.groupSname = groupSname;
	}
	
	public String getGroupLname() {
		return groupLname;
	}
	public void setGroupLname(String groupLname) {
		this.groupLname = groupLname;
	}

	public String getGamName() {
		return gamName;
	}
	public void setGamName(String gamName) {
		this.gamName = gamName;
	}
	
	
	public String getGamPhone() {
		return gamPhone;
	}
	public void setGamPhone(String gamPhone) {
		this.gamPhone = gamPhone;
	}
	

	public String getGamFax() {
		return gamFax;
	}
	public void setGamFax(String gamFax) {
		this.gamFax = gamFax;
	}

	public String getGamEmail() {
		return gamEmail;
	}
	
	public void setGamEmail(String gamEmail) {
		this.gamEmail = gamEmail;
	}
	

	public String getGamLanguage() {
		return gamLanguage;
	}
	public void setGamLanguage(String gamLanguage) {
		this.gamLanguage = gamLanguage;
	}

	public String getTreasureName() {
		return treasureName;
	}
	public void setTreasureName(String treasureName) {
		this.treasureName = treasureName;
	}

	public String getTreasurePhone() {
		return treasurePhone;
	}
	public void setTreasurePhone(String treasurePhone) {
		this.treasurePhone = treasurePhone;
	}

	public String getTreasureFax() {
		return treasureFax;
	}
	public void setTreasureFax(String treasureFax) {
		this.treasureFax = treasureFax;
	}

	public String getTreasureEmail() {
		return treasureEmail;
	}
	public void setTreasureEmail(String treasureEmail) {
		this.treasureEmail = treasureEmail;
	}

	public String getTreasureLanguage() {
		return treasureLanguage;
	}
	public void setTreasureLanguage(String treasureLanguage) {
		this.treasureLanguage = treasureLanguage;
	}

	public String getCurrencyCode() {
		return currencyCode;
	}
	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	public String getCountryCode() {
		return countryCode;
	}
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public Integer getInsertDate() {
		return insertDate;
	}
	public void setInsertDate(Integer insertDate) {
		this.insertDate = insertDate;
	}

	public Integer getDeleteDate() {
		return deleteDate;
	}
	public void setDeleteDate(Integer deleteDate) {
		this.deleteDate = deleteDate;
	}

	public Integer getDataVersionNo() {
		return dataVersionNo;
	}
	public void setDataVersionNo(Integer dataVersionNo) {
		this.dataVersionNo = dataVersionNo;
	}

/*	public Timestamp getChangeTimestamp() {
		return changeTimestamp;
	}
	public void setChangeTimestamp(Timestamp changeTimestamp) {
		this.changeTimestamp = changeTimestamp;
	}*/

	public String getChangeUserId() {
		return changeUserId;
	}
	public void setChangeUserId(String changeUserId) {
		this.changeUserId = changeUserId;
	}

	public String getChangeMsgCarrierId() {
		return changeMsgCarrierId;
	}
	public void setChangeMsgCarrierId(String changeMsgCarrierId) {
		this.changeMsgCarrierId = changeMsgCarrierId;
	}

	public String getChangeCountry() {
		return changeCountry;
	}
	public void setChangeCountry(String changeCountry) {
		this.changeCountry = changeCountry;
	}

	public String getChangeEntity() {
		return changeEntity;
	}
	public void setChangeEntity(String changeEntity) {
		this.changeEntity = changeEntity;
	}

	public String getChangeBranch() {
		return changeBranch;
	}
	public void setChangeBranch(String changeBranch) {
		this.changeBranch = changeBranch;
	}

	public String getBusinessUnit() {
		return businessUnit;
	}
	public void setBusinessUnit(String businessUnit) {
		this.businessUnit = businessUnit;
	}

	public Integer getChangeSequence() {
		return changeSequence;
	}
	public void setChangeSequence(Integer changeSequence) {
		this.changeSequence = changeSequence;
	}

	public String getTimeDif() {
		return timeDif;
	}
	public void setTimeDif(String timeDif) {
		this.timeDif = timeDif;
	}

	public String getEntity() {
		return entity;
	}
	public void setEntity(String entity) {
		this.entity = entity;
	}

	public String getEdiPrisma() {
		return ediPrisma;
	}
	public void setEdiPrisma(String ediPrisma) {
		this.ediPrisma = ediPrisma;
	}

	public String toString(){
		return ReflectionToStringBuilder.toString(this);

	}

}
