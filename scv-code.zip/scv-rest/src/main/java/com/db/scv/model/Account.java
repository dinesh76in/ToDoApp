package com.db.scv.model;

public class Account {
	
	private String mt940AcId;
	private Integer accSequence;
	private String currencyCode;
	private String accountType;
	private String accountTypeStr;
	private String companySname;
	private String groupSname;
	private String customerAccount;
	private String customerName;
	private String flagResident;
	private Integer bankId;
	private String branchNumber;
	private String branchName;
	private String yearBase;
	private String flagDailyTran;
	private Integer lastBookBalance;
	private Integer lastBookDate;
	private Integer firstBookDate;
	private String firstBakValue;
    private String flagStatus;
    private String flagNotional;
    private Integer insertDate;
	private Integer deleteDate;
	private Integer dataVersionNo;
	private String changeTimestamp;
	private String changeUserId;
	private String changeMsgCarrierId;
	private String changeCountry;
	private Integer changeEntity;
	private Integer changeBranch;
	private String currencyCode2;
    private String controlFlags;
    private String flagMT942;
	private Integer mt942Date;
	private String runningMode;
	private String changeSequence;
	private String ibanCode;
    private String flagBtrn;
	private Integer btrnDate;
    private Integer blockAmount;
    private String dpeAccountName;
	private String accountRole;
	private Integer refBranchId;
	private Integer  batchSeq;
	private String  reconcileTx;
	private Integer  branch;
	private String  flagKumv;
	private Integer kumvDate;
	private String flagTypeMt942;
	private boolean isMasterAccount;
	
	
	public String getMt940AcId() {
		return mt940AcId;
	}
	public void setMt940AcId(String mt940AcId) {
		this.mt940AcId = mt940AcId;
	}
	public Integer getAccSequence() {
		return accSequence;
	}
	public void setAccSequence(Integer accSequence) {
		this.accSequence = accSequence;
	}
	public String getCurrencyCode() {
		return currencyCode;
	}
	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public String getCompanySname() {
		return companySname;
	}
	public void setCompanySname(String companySname) {
		this.companySname = companySname;
	}
	public String getGroupSname() {
		return groupSname;
	}
	public void setGroupSname(String groupSname) {
		this.groupSname = groupSname;
	}
	public String getCustomerAccount() {
		return customerAccount;
	}
	public void setCustomerAccount(String customerAccount) {
		this.customerAccount = customerAccount;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getFlagResident() {
		return flagResident;
	}
	public void setFlagResident(String flagResident) {
		this.flagResident = flagResident;
	}
	public Integer getBankId() {
		return bankId;
	}
	public void setBankId(Integer bankId) {
		this.bankId = bankId;
	}
	public String getBranchNumber() {
		return branchNumber;
	}
	public void setBranchNumber(String branchNumber) {
		this.branchNumber = branchNumber;
	}
	public String getBranchName() {
		return branchName;
	}
	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}
	public String getYearBase() {
		return yearBase;
	}
	public void setYearBase(String yearBase) {
		this.yearBase = yearBase;
	}
	public String getFlagDailyTran() {
		return flagDailyTran;
	}
	public void setFlagDailyTran(String flagDailyTran) {
		this.flagDailyTran = flagDailyTran;
	}
	public Integer getLastBookBalance() {
		return lastBookBalance;
	}
	public void setLastBookBalance(Integer lastBookBalance) {
		this.lastBookBalance = lastBookBalance;
	}
	public Integer getLastBookDate() {
		return lastBookDate;
	}
	public void setLastBookDate(Integer lastBookDate) {
		this.lastBookDate = lastBookDate;
	}
	public Integer getFirstBookDate() {
		return firstBookDate;
	}
	public void setFirstBookDate(Integer firstBookDate) {
		this.firstBookDate = firstBookDate;
	}
	public String getFirstBakValue() {
		return firstBakValue;
	}
	public void setFirstBakValue(String firstBakValue) {
		this.firstBakValue = firstBakValue;
	}
	public String getFlagStatus() {
		return flagStatus;
	}
	public void setFlagStatus(String flagStatus) {
		this.flagStatus = flagStatus;
	}
	public String getFlagNotional() {
		return flagNotional;
	}
	public void setFlagNotional(String flagNotional) {
		this.flagNotional = flagNotional;
	}
	public Integer getInsertDate() {
		return insertDate;
	}
	public void setInsertDate(Integer insertDate) {
		this.insertDate = insertDate;
	}
	public Integer getDeleteDate() {
		return deleteDate;
	}
	public void setDeleteDate(Integer deleteDate) {
		this.deleteDate = deleteDate;
	}
	public Integer getDataVersionNo() {
		return dataVersionNo;
	}
	public void setDataVersionNo(Integer dataVersionNo) {
		this.dataVersionNo = dataVersionNo;
	}
	public String getChangeTimestamp() {
		return changeTimestamp;
	}
	public void setChangeTimestamp(String changeTimestamp) {
		this.changeTimestamp = changeTimestamp;
	}
	public String getChangeUserId() {
		return changeUserId;
	}
	public void setChangeUserId(String changeUserId) {
		this.changeUserId = changeUserId;
	}
	public String getChangeMsgCarrierId() {
		return changeMsgCarrierId;
	}
	public void setChangeMsgCarrierId(String changeMsgCarrierId) {
		this.changeMsgCarrierId = changeMsgCarrierId;
	}
	public String getChangeCountry() {
		return changeCountry;
	}
	public void setChangeCountry(String changeCountry) {
		this.changeCountry = changeCountry;
	}
	public Integer getChangeEntity() {
		return changeEntity;
	}
	public void setChangeEntity(Integer changeEntity) {
		this.changeEntity = changeEntity;
	}
	public Integer getChangeBranch() {
		return changeBranch;
	}
	public void setChangeBranch(Integer changeBranch) {
		this.changeBranch = changeBranch;
	}
	public String getCurrencyCode2() {
		return currencyCode2;
	}
	public void setCurrencyCode2(String currencyCode2) {
		this.currencyCode2 = currencyCode2;
	}
	public String getControlFlags() {
		return controlFlags;
	}
	public void setControlFlags(String controlFlags) {
		this.controlFlags = controlFlags;
	}
	public String getFlagMT942() {
		return flagMT942;
	}
	public void setFlagMT942(String flagMT942) {
		this.flagMT942 = flagMT942;
	}
	public Integer getMt942Date() {
		return mt942Date;
	}
	public void setMt942Date(Integer mt942Date) {
		this.mt942Date = mt942Date;
	}
	public String getRunningMode() {
		return runningMode;
	}
	public void setRunningMode(String runningMode) {
		this.runningMode = runningMode;
	}
	public String getChangeSequence() {
		return changeSequence;
	}
	public void setChangeSequence(String changeSequence) {
		this.changeSequence = changeSequence;
	}
	public String getIbanCode() {
		return ibanCode;
	}
	public void setIbanCode(String ibanCode) {
		this.ibanCode = ibanCode;
	}
	public String getFlagBtrn() {
		return flagBtrn;
	}
	public void setFlagBtrn(String flagBtrn) {
		this.flagBtrn = flagBtrn;
	}
	public Integer getBtrnDate() {
		return btrnDate;
	}
	public void setBtrnDate(Integer btrnDate) {
		this.btrnDate = btrnDate;
	}
	public Integer getBlockAmount() {
		return blockAmount;
	}
	public void setBlockAmount(Integer blockAmount) {
		this.blockAmount = blockAmount;
	}
	public String getDpeAccountName() {
		return dpeAccountName;
	}
	public void setDpeAccountName(String dpeAccountName) {
		this.dpeAccountName = dpeAccountName;
	}
	public String getAccountRole() {
		return accountRole;
	}
	public void setAccountRole(String accountRole) {
		this.accountRole = accountRole;
	}
	public Integer getRefBranchId() {
		return refBranchId;
	}
	public void setRefBranchId(Integer refBranchId) {
		this.refBranchId = refBranchId;
	}
	public Integer getBatchSeq() {
		return batchSeq;
	}
	public void setBatchSeq(Integer batchSeq) {
		this.batchSeq = batchSeq;
	}
	public String getReconcileTx() {
		return reconcileTx;
	}
	public void setReconcileTx(String reconcileTx) {
		this.reconcileTx = reconcileTx;
	}
	public Integer getBranch() {
		return branch;
	}
	public void setBranch(Integer branch) {
		this.branch = branch;
	}
	public String getFlagKumv() {
		return flagKumv;
	}
	public void setFlagKumv(String flagKumv) {
		this.flagKumv = flagKumv;
	}
	public Integer getKumvDate() {
		return kumvDate;
	}
	public void setKumvDate(Integer kumvDate) {
		this.kumvDate = kumvDate;
	}
	public String getFlagTypeMt942() {
		return flagTypeMt942;
	}
	public void setFlagTypeMt942(String flagTypeMt942) {
		this.flagTypeMt942 = flagTypeMt942;
	}
    public boolean isMasterAccount() {
		return isMasterAccount;
	}
	public void setMasterAccount(boolean isMasterAccount) {
		this.isMasterAccount = isMasterAccount;
	}
	public String getAccountTypeStr() {
		return accountTypeStr;
	}
	public void setAccountTypeStr(String accountTypeStr) {
		this.accountTypeStr = accountTypeStr;
	}

}
