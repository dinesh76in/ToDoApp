package com.db.scv.resource;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.GenericEntity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.db.scv.model.Rule;
import com.db.scv.service.RuleService;

@Path("/rule")
@Component
public class RuleResource {

	private static final Logger LOG = LoggerFactory.getLogger(RuleResource.class);

	@Autowired
	private RuleService ruleService = null;

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/cashgroup/{groupSequence}")
	public Response getClientProducts(@PathParam("groupSequence")Integer groupSequence) {
		LOG.info(" Fetching list of rules for cash group  ");
		List<Rule> cashGroupRules = ruleService.getCashGroupRules(groupSequence);

		LOG.info(" Number of rules fetched -  " + cashGroupRules.size());
		GenericEntity<List<Rule>> ge = new GenericEntity<List<Rule>>(cashGroupRules) {};
		return Response.ok(ge).build();
	}
}
