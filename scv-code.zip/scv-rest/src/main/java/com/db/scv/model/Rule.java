package com.db.scv.model;

public class Rule {
	
	private Integer ruleSequence;
	private Integer ruleGroupSeq;
	private String ruleDescription;
	private String ruleType;
	private Integer ruleOrder;
	private Integer initialDate;
	private Integer finalDate;
	private String weekCal;
	private String weekInverse;
	private String monthCal;
	private String monthInverse;
	private Integer interval;
	private String frequency;
	private Integer frequencyDate;
	private Integer nextprocessDate;
	private Integer lastprocessDate;
	private String flagHolidays;
	private Integer futureValues;
	private Integer backValuesCredit;
	private Integer backValuesDebit;
	private Integer minDebitDate;
	private Integer accSequence;
	private Integer insertDate;
	private Integer deleteDate;
	private String ruleCritical;
	private Integer dataVersionNo;
	private String changeTimestamp;
	private String changeUserId;
	private String changeMsgCarrierId;
	private String changeCountry;
	private Integer changeEntity;
	private Integer changeBranch;
	private Integer spreadDays;
	private String phase445;
	private String runningMode;
	private Integer spreadFreqDate;
	private String country;
	private Integer changeSequence;
	private String procBranch;
	private Integer productSeq;
	public Integer getRuleSequence() {
		return ruleSequence;
	}
	public void setRuleSequence(Integer ruleSequence) {
		this.ruleSequence = ruleSequence;
	}
	public Integer getRuleGroupSeq() {
		return ruleGroupSeq;
	}
	public void setRuleGroupSeq(Integer ruleGroupSeq) {
		this.ruleGroupSeq = ruleGroupSeq;
	}
	public String getRuleDescription() {
		return ruleDescription;
	}
	public void setRuleDescription(String ruleDescription) {
		this.ruleDescription = ruleDescription;
	}
	public String getRuleType() {
		return ruleType;
	}
	public void setRuleType(String ruleType) {
		this.ruleType = ruleType;
	}
	public Integer getRuleOrder() {
		return ruleOrder;
	}
	public void setRuleOrder(Integer ruleOrder) {
		this.ruleOrder = ruleOrder;
	}
	public Integer getInitialDate() {
		return initialDate;
	}
	public void setInitialDate(Integer initialDate) {
		this.initialDate = initialDate;
	}
	public Integer getFinalDate() {
		return finalDate;
	}
	public void setFinalDate(Integer finalDate) {
		this.finalDate = finalDate;
	}
	public String getWeekCal() {
		return weekCal;
	}
	public void setWeekCal(String weekCal) {
		this.weekCal = weekCal;
	}
	public String getWeekInverse() {
		return weekInverse;
	}
	public void setWeekInverse(String weekInverse) {
		this.weekInverse = weekInverse;
	}
	public String getMonthCal() {
		return monthCal;
	}
	public void setMonthCal(String monthCal) {
		this.monthCal = monthCal;
	}
	public String getMonthInverse() {
		return monthInverse;
	}
	public void setMonthInverse(String monthInverse) {
		this.monthInverse = monthInverse;
	}
	public Integer getInterval() {
		return interval;
	}
	public void setInterval(Integer interval) {
		this.interval = interval;
	}
	public String getFrequency() {
		return frequency;
	}
	public void setFrequency(String frequency) {
		this.frequency = frequency;
	}
	public Integer getFrequencyDate() {
		return frequencyDate;
	}
	public void setFrequencyDate(Integer frequencyDate) {
		this.frequencyDate = frequencyDate;
	}
	public Integer getNextprocessDate() {
		return nextprocessDate;
	}
	public void setNextprocessDate(Integer nextprocessDate) {
		this.nextprocessDate = nextprocessDate;
	}
	public Integer getLastprocessDate() {
		return lastprocessDate;
	}
	public void setLastprocessDate(Integer lastprocessDate) {
		this.lastprocessDate = lastprocessDate;
	}
	public String getFlagHolidays() {
		return flagHolidays;
	}
	public void setFlagHolidays(String flagHolidays) {
		this.flagHolidays = flagHolidays;
	}
	public Integer getFutureValues() {
		return futureValues;
	}
	public void setFutureValues(Integer futureValues) {
		this.futureValues = futureValues;
	}
	public Integer getBackValuesCredit() {
		return backValuesCredit;
	}
	public void setBackValuesCredit(Integer backValuesCredit) {
		this.backValuesCredit = backValuesCredit;
	}
	public Integer getBackValuesDebit() {
		return backValuesDebit;
	}
	public void setBackValuesDebit(Integer backValuesDebit) {
		this.backValuesDebit = backValuesDebit;
	}
	public Integer getMinDebitDate() {
		return minDebitDate;
	}
	public void setMinDebitDate(Integer minDebitDate) {
		this.minDebitDate = minDebitDate;
	}
	public Integer getAccSequence() {
		return accSequence;
	}
	public void setAccSequence(Integer accSequence) {
		this.accSequence = accSequence;
	}
	public Integer getInsertDate() {
		return insertDate;
	}
	public void setInsertDate(Integer insertDate) {
		this.insertDate = insertDate;
	}
	public Integer getDeleteDate() {
		return deleteDate;
	}
	public void setDeleteDate(Integer deleteDate) {
		this.deleteDate = deleteDate;
	}
	public String getRuleCritical() {
		return ruleCritical;
	}
	public void setRuleCritical(String ruleCritical) {
		this.ruleCritical = ruleCritical;
	}
	public Integer getDataVersionNo() {
		return dataVersionNo;
	}
	public void setDataVersionNo(Integer dataVersionNo) {
		this.dataVersionNo = dataVersionNo;
	}
	public String getChangeTimestamp() {
		return changeTimestamp;
	}
	public void setChangeTimestamp(String changeTimestamp) {
		this.changeTimestamp = changeTimestamp;
	}
	public String getChangeUserId() {
		return changeUserId;
	}
	public void setChangeUserId(String changeUserId) {
		this.changeUserId = changeUserId;
	}
	public String getChangeMsgCarrierId() {
		return changeMsgCarrierId;
	}
	public void setChangeMsgCarrierId(String changeMsgCarrierId) {
		this.changeMsgCarrierId = changeMsgCarrierId;
	}
	public String getChangeCountry() {
		return changeCountry;
	}
	public void setChangeCountry(String changeCountry) {
		this.changeCountry = changeCountry;
	}
	public Integer getChangeEntity() {
		return changeEntity;
	}
	public void setChangeEntity(Integer changeEntity) {
		this.changeEntity = changeEntity;
	}
	public Integer getChangeBranch() {
		return changeBranch;
	}
	public void setChangeBranch(Integer changeBranch) {
		this.changeBranch = changeBranch;
	}
	public Integer getSpreadDays() {
		return spreadDays;
	}
	public void setSpreadDays(Integer spreadDays) {
		this.spreadDays = spreadDays;
	}
	public String getPhase445() {
		return phase445;
	}
	public void setPhase445(String phase445) {
		this.phase445 = phase445;
	}
	public String getRunningMode() {
		return runningMode;
	}
	public void setRunningMode(String runningMode) {
		this.runningMode = runningMode;
	}
	public Integer getSpreadFreqDate() {
		return spreadFreqDate;
	}
	public void setSpreadFreqDate(Integer spreadFreqDate) {
		this.spreadFreqDate = spreadFreqDate;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public Integer getChangeSequence() {
		return changeSequence;
	}
	public void setChangeSequence(Integer changeSequence) {
		this.changeSequence = changeSequence;
	}
	public String getProcBranch() {
		return procBranch;
	}
	public void setProcBranch(String procBranch) {
		this.procBranch = procBranch;
	}
	public Integer getProductSeq() {
		return productSeq;
	}
	public void setProductSeq(Integer productSeq) {
		this.productSeq = productSeq;
	}
}
