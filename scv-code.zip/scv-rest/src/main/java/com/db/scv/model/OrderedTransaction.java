package com.db.scv.model;

import java.math.BigDecimal;
import java.sql.Timestamp;

public class OrderedTransaction {

	private Integer orderIdentifier;
	private String sourceMt940Acc;
	private String targetMt940Acc;
	private String currencyCode;
	private BigDecimal amount;
	private Integer sourceExecDate;
	private Integer sourceValueDate;
	private Integer targetExecDate;
	private Integer targetValueDate;
	private String paymentDetails1;
	private String paymentDetails2;
	private String paymentDetails3;
	private String ordStatus;
	private Integer ordStatusDate;
	private BigDecimal balanceSource;
	private BigDecimal balanceTarget;
	private Integer plannedTrnId;
	private Integer groupSequence;
	private Integer rulSequence;
	private Integer dataVersionNo;
	private Timestamp changeTimeStamp;
	private String changeUserId;
	private String changeMsgCarrierId;
	private String changeCountry;
	private Integer changeEntity;
	private Integer changeBranch;
	private Integer insertDate;
	private Integer deleteDate;
	private Integer orderIdentOrig;
	private String entity;
	private String flags;
	private String procBranch;
	private Integer productSeq;
	private Integer changeSequence;

	public Integer getOrderIdentifier() {
		return orderIdentifier;
	}

	public void setOrderIdentifier(Integer orderIdentifier) {
		this.orderIdentifier = orderIdentifier;
	}

	public String getSourceMt940Acc() {
		return sourceMt940Acc;
	}

	public void setSourceMt940Acc(String sourceMt940Acc) {
		this.sourceMt940Acc = sourceMt940Acc;
	}

	public String getTargetMt940Acc() {
		return targetMt940Acc;
	}

	public void setTargetMt940Acc(String targetMt940Acc) {
		this.targetMt940Acc = targetMt940Acc;
	}

	public String getCurrencyCode() {
		return currencyCode;
	}

	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public Integer getSourceExecDate() {
		return sourceExecDate;
	}

	public void setSourceExecDate(Integer sourceExecDate) {
		this.sourceExecDate = sourceExecDate;
	}

	public Integer getSourceValueDate() {
		return sourceValueDate;
	}

	public void setSourceValueDate(Integer sourceValueDate) {
		this.sourceValueDate = sourceValueDate;
	}

	public Integer getTargetExecDate() {
		return targetExecDate;
	}

	public void setTargetExecDate(Integer targetExecDate) {
		this.targetExecDate = targetExecDate;
	}

	public Integer getTargetValueDate() {
		return targetValueDate;
	}

	public void setTargetValueDate(Integer targetValueDate) {
		this.targetValueDate = targetValueDate;
	}

	public String getPaymentDetails1() {
		return paymentDetails1;
	}

	public void setPaymentDetails1(String paymentDetails1) {
		this.paymentDetails1 = paymentDetails1;
	}

	public String getPaymentDetails2() {
		return paymentDetails2;
	}

	public void setPaymentDetails2(String paymentDetails2) {
		this.paymentDetails2 = paymentDetails2;
	}

	public String getPaymentDetails3() {
		return paymentDetails3;
	}

	public void setPaymentDetails3(String paymentDetails3) {
		this.paymentDetails3 = paymentDetails3;
	}

	public String getOrdStatus() {
		return ordStatus;
	}

	public void setOrdStatus(String ordStatus) {
		this.ordStatus = ordStatus;
	}

	public Integer getOrdStatusDate() {
		return ordStatusDate;
	}

	public void setOrdStatusDate(Integer ordStatusDate) {
		this.ordStatusDate = ordStatusDate;
	}

	public BigDecimal getBalanceSource() {
		return balanceSource;
	}

	public void setBalanceSource(BigDecimal balanceSource) {
		this.balanceSource = balanceSource;
	}

	public BigDecimal getBalanceTarget() {
		return balanceTarget;
	}

	public void setBalanceTarget(BigDecimal balanceTarget) {
		this.balanceTarget = balanceTarget;
	}

	public Integer getPlannedTrnId() {
		return plannedTrnId;
	}

	public void setPlannedTrnId(Integer plannedTrnId) {
		this.plannedTrnId = plannedTrnId;
	}

	public Integer getGroupSequence() {
		return groupSequence;
	}

	public void setGroupSequence(Integer groupSequence) {
		this.groupSequence = groupSequence;
	}

	public Integer getRulSequence() {
		return rulSequence;
	}

	public void setRulSequence(Integer rulSequence) {
		this.rulSequence = rulSequence;
	}

	public Integer getDataVersionNo() {
		return dataVersionNo;
	}

	public void setDataVersionNo(Integer dataVersionNo) {
		this.dataVersionNo = dataVersionNo;
	}

	public Timestamp getChangeTimeStamp() {
		return changeTimeStamp;
	}

	public void setChangeTimeStamp(Timestamp changeTimeStamp) {
		this.changeTimeStamp = changeTimeStamp;
	}

	public String getChangeUserId() {
		return changeUserId;
	}

	public void setChangeUserId(String changeUserId) {
		this.changeUserId = changeUserId;
	}

	public String getChangeMsgCarrierId() {
		return changeMsgCarrierId;
	}

	public void setChangeMsgCarrierId(String changeMsgCarrierId) {
		this.changeMsgCarrierId = changeMsgCarrierId;
	}

	public String getChangeCountry() {
		return changeCountry;
	}

	public void setChangeCountry(String changeCountry) {
		this.changeCountry = changeCountry;
	}

	public Integer getChangeEntity() {
		return changeEntity;
	}

	public void setChangeEntity(Integer changeEntity) {
		this.changeEntity = changeEntity;
	}

	public Integer getChangeBranch() {
		return changeBranch;
	}

	public void setChangeBranch(Integer changeBranch) {
		this.changeBranch = changeBranch;
	}

	public Integer getInsertDate() {
		return insertDate;
	}

	public void setInsertDate(Integer insertDate) {
		this.insertDate = insertDate;
	}

	public Integer getDeleteDate() {
		return deleteDate;
	}

	public void setDeleteDate(Integer deleteDate) {
		this.deleteDate = deleteDate;
	}

	public Integer getOrderIdentOrig() {
		return orderIdentOrig;
	}

	public void setOrderIdentOrig(Integer orderIdentOrig) {
		this.orderIdentOrig = orderIdentOrig;
	}

	public String getEntity() {
		return entity;
	}

	public void setEntity(String entity) {
		this.entity = entity;
	}

	public String getFlags() {
		return flags;
	}

	public void setFlags(String flags) {
		this.flags = flags;
	}

	public String getProcBranch() {
		return procBranch;
	}

	public void setProcBranch(String procBranch) {
		this.procBranch = procBranch;
	}

	public Integer getProductSeq() {
		return productSeq;
	}

	public void setProductSeq(Integer productSeq) {
		this.productSeq = productSeq;
	}

	public Integer getChangeSequence() {
		return changeSequence;
	}

	public void setChangeSequence(Integer changeSequence) {
		this.changeSequence = changeSequence;
	}

}
