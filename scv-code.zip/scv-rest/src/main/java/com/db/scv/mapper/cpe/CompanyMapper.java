package com.db.scv.mapper.cpe;

import java.util.List;

import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;

import com.db.scv.model.Company;

public interface CompanyMapper {
	  @Select("Select * from Pz003T where group_sname like '%'||#{groupSname}||'%'")
      @Results(value = {
    	      @Result(property = "cmpSname", column = "CMP_SNAME"),
    	      @Result(property = "countryCode", column = "COUNTRY_CODE"),
    	      @Result(property = "cmpLname", column = "CMP_LNAME"),
    	      @Result(property = "cmpAddr1", column = "CMP_ADDR_1"),       
    	      @Result(property = "cmpAddr2", column = "CMP_ADDR_2"),
    	      @Result(property = "cmpAddr3", column = "CMP_ADDR_3"),
    	      @Result(property = "groupSname", column = "GROUP_SNAME"),
    	      @Result(property = "cmpContactPerson", column = "CMP_CONTACT_PERSON"),
    	      @Result(property = "cmpContactPhone", column = "CMP_CONTACT_PHONE"),
    	      @Result(property = "cmpContactFax", column = "CMP_CONTACT_FAX"),       
    	      @Result(property = "cmpContactEmail", column = "TREASURE_EMAIL"),
    	      @Result(property = "insertDate", column = "INSERT_DATE"),
    	      @Result(property = "deleteDate", column = "DELETE_DATE"),
    	      @Result(property = "dataVersionNo", column = "DATA_VERSION_NO"),
    	      @Result(property = "changeTimestamp", column = "CHANGE_TS"), 
    	      @Result(property = "changeUserId", column = "CHANGE_USERID"),
    	      @Result(property = "changeMsgCarrierId", column = "CHG_MESS_CARR_ID"), 
    	      @Result(property = "changeCountry", column = "CHANGE_COUNTRY"),
    	      @Result(property = "changeEntity", column = "CHANGE_ENTITY"),
    	      @Result(property = "changeBranch", column = "CHANGE_BRANCH"),
    	      @Result(property = "changeSequence", column = "CHANGE_SEQUENCE"),
    	      @Result(property = "cmpAddr4", column = "CMP_ADDR_4"),       
    	      @Result(property = "cmpAddr5", column = "CMP_ADDR_5"),
    	      @Result(property = "cmpAddr6", column = "CMP_ADDR_6"),       
    	      @Result(property = "cmpAddr7", column = "CMP_ADDR_7"),
    	      @Result(property = "cmpAddr8", column = "CMP_ADDR_8")
    	   })
	  public List<Company> getClientCompanies(String groupSname);
 	
	  @Select("Select * from Pz003T where cmp_sname=#{cmpnySname}")
      @Results(value = {
    	      @Result(property = "cmpSname", column = "CMP_SNAME"),
    	      @Result(property = "countryCode", column = "COUNTRY_CODE"),
    	      @Result(property = "cmpLname", column = "CMP_LNAME"),
    	      @Result(property = "cmpAddr1", column = "CMP_ADDR_1"),       
    	      @Result(property = "cmpAddr2", column = "CMP_ADDR_2"),
    	      @Result(property = "cmpAddr3", column = "CMP_ADDR_3"),
    	      @Result(property = "groupSname", column = "GROUP_SNAME"),
    	      @Result(property = "cmpContactPerson", column = "CMP_CONTACT_PERSON"),
    	      @Result(property = "cmpContactPhone", column = "CMP_CONTACT_PHONE"),
    	      @Result(property = "cmpContactFax", column = "CMP_CONTACT_FAX"),       
    	      @Result(property = "cmpContactEmail", column = "TREASURE_EMAIL"),
    	      @Result(property = "insertDate", column = "INSERT_DATE"),
    	      @Result(property = "deleteDate", column = "DELETE_DATE"),
    	      @Result(property = "dataVersionNo", column = "DATA_VERSION_NO"),
    	      @Result(property = "changeTimestamp", column = "CHANGE_TS"), 
    	      @Result(property = "changeUserId", column = "CHANGE_USERID"),
    	      @Result(property = "changeMsgCarrierId", column = "CHG_MESS_CARR_ID"), 
    	      @Result(property = "changeCountry", column = "CHANGE_COUNTRY"),
    	      @Result(property = "changeEntity", column = "CHANGE_ENTITY"),
    	      @Result(property = "changeBranch", column = "CHANGE_BRANCH"),
    	      @Result(property = "changeSequence", column = "CHANGE_SEQUENCE"),
    	      @Result(property = "cmpAddr4", column = "CMP_ADDR_4"),       
    	      @Result(property = "cmpAddr5", column = "CMP_ADDR_5"),
    	      @Result(property = "cmpAddr6", column = "CMP_ADDR_6"),       
    	      @Result(property = "cmpAddr7", column = "CMP_ADDR_7"),
    	      @Result(property = "cmpAddr8", column = "CMP_ADDR_8")
    	   })
	  public Company getCompany(String cmpnySname);
}
