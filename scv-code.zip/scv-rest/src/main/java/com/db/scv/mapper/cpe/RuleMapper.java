package com.db.scv.mapper.cpe;

import java.util.List;

import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;

import com.db.scv.model.Rule;

public interface RuleMapper {

	 @Select("Select * from PZ010T where rule_group_seq=#{groupSequence}")
     @Results(value = {
   	      @Result(property = "ruleSequence", column = "RULE_SEQUENCE"),
   	      @Result(property = "ruleGroupSeq", column = "RULE_GROUP_SEQ"),
   	      @Result(property = "ruleDescription", column = "RULE_DESCRIPTION"),
   	      @Result(property = "ruleType", column = "RULE_TYPE"),       
   	      @Result(property = "ruleOrder", column = "RULE_ORDER"),
   	      @Result(property = "initialDate", column = "INITIAL_DATE"),
   	      @Result(property = "finalDate", column = "FINAL_DATE"),
   	      @Result(property = "weekCal", column = "WEEK_CAL"),
   	      @Result(property = "weekInverse", column = "WEEK_INVERSE"),
   	      @Result(property = "monthCal", column = "MONTH_CAL"),       
   	      @Result(property = "monthInverse", column = "MONTH_INVERSE"),
   	      @Result(property = "interval", column = "INTERVAL"),
   	      @Result(property = "frequency", column = "FREQUENCY"),
   	      @Result(property = "frequencyDate", column = "FREQUENCY_DATE"),
   	      @Result(property = "nextprocessDate", column = "NEXT_PROCESS_DATE"),       
   	      @Result(property = "lastprocessDate", column = "LAST_PROCESS_DATE"),
   	      @Result(property = "flagHolidays", column = "FLAG_HOLIDAYS"),
   	      @Result(property = "futureValues", column = "FUTURE_VALUES"),
   	      @Result(property = "backValuesCredit", column = "BACKVALUES_CREDIT"),
   	      @Result(property = "backValuesDebit", column = "BACKVALUES_DEBIT"),  
   	      @Result(property = "minDebitDate", column = "MIN_DEBIT_DATE"),
   	      @Result(property = "accSequence", column = "ACC_SEQUENCE"),
	      @Result(property = "ruleCritical", column = "RULE_CRITICAL"),  
   	      @Result(property = "insertDate", column = "INSERT_DATE"),       
	      @Result(property = "deleteDate", column = "DELETE_DATE"),
	      @Result(property = "dataVersionNo", column = "DATA_VERSION_NO"),
	      @Result(property = "changeTimestamp", column = "CHANGE_TS"),
	      @Result(property = "changeUserId", column = "CHANGE_USERID"),
	      @Result(property = "changeMsgCarrierId", column = "CHG_MESS_CARR_ID"),   
   	      @Result(property = "changeCountry", column = "CHANGE_COUNTRY"),
   	      @Result(property = "changeEntity", column = "CHANGE_ENTITY"),
   	      @Result(property = "changeBranch", column = "CHANGE_BRANCH"), 
   	      @Result(property = "spreadDays", column = "SPREAD_DAYS"),
   	      @Result(property = "phase445", column = "PHASE_445"),
   	      @Result(property = "runningMode", column = "RUNNING_MODE"),  
   	      @Result(property = "spreadFreqDate", column = "SPREAD_FREQ_DATE"),
   	      @Result(property = "country", column = "COUNTRY"),
          @Result(property = "changeSequence", column = "CHANGE_SEQUENCE"),  
	      @Result(property = "procBranch", column = "PROC_BRANCH"),       
	      @Result(property = "productSeq", column = "PRODUCT_SEQ")
	    })
	  public List<Rule> getRulesForCashGroup(Integer groupSequence);
	
}
