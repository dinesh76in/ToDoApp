package com.db.scv.resource;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.GenericEntity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.db.scv.model.CashGroup;
import com.db.scv.service.CashGroupService;

@Path("/cashgroup")
@Component
public class CashGroupResource {
	
	private static final Logger LOG = LoggerFactory.getLogger(CashGroupResource.class);
	
	@Autowired
	private CashGroupService cashGroupService = null;
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/client/{groupSname}")
	public Response getClientCashGroups(@PathParam("groupSname")String groupSname) {
		LOG.info(" Fetching all Cash groups for client "+groupSname);
		List<CashGroup> clientsCashGroups = cashGroupService.getClientCashGroups(groupSname);

		LOG.info(" Number of clients Cash Groups fetched -  " + clientsCashGroups.size());
		GenericEntity<List<CashGroup>> ge = new GenericEntity<List<CashGroup>>(clientsCashGroups) {};
		return Response.ok(ge).build();
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/{accSequence}")
	public Response getCashGroupDetails(@PathParam("accSequence")Integer accSequence) {
		LOG.info(" Fetching Cash group for accSequence "+accSequence);
		CashGroup cashGroup = cashGroupService.getCashGroupById(accSequence);

		LOG.info(" Cash Group fetched -  " + cashGroup);
		GenericEntity<CashGroup> ge = new GenericEntity<CashGroup>(cashGroup) {};
		return Response.ok(ge).build();
	}

}
