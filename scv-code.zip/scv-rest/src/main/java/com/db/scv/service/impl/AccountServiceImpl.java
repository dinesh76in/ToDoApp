package com.db.scv.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.db.scv.mapper.cpe.AccountMapper;
import com.db.scv.model.Account;
import com.db.scv.model.AccountInfo;
import com.db.scv.service.AccountService;

@Component
@Service
public class AccountServiceImpl implements AccountService {

	private static final Logger LOG = LoggerFactory.getLogger(AccountServiceImpl.class);

	@Autowired
	private AccountMapper accountMapper = null;

	@Override
	public List<Account> getClientAccounts(String groupSname) {
		LOG.info("Fetching Account for client " + groupSname);
		List<Account> accounts = accountMapper.getCompanyGroupAccounts(groupSname);
		return enrichAccountType(accounts, groupSname);
	}

	@Override
	public List<Account> getCompanyAccounts( String groupSname,String cmpnySname) {
		LOG.info("Fetching Account for company " + cmpnySname);
		
		List<Account> companyAccounts=accountMapper.getCompanyAccounts(cmpnySname);
		return enrichAccountType(companyAccounts, groupSname);
	}

	@Override
	public Account getAccountBySequence(Integer accSequence) {
		LOG.info("Fetching Account by sequence " + accSequence);
		return accountMapper.getAccountBySequence(accSequence);
	}

	@Override
	public Account getAccountById(String mt940AccId) {
		LOG.info("Fetching Account by mt940AccId  " + mt940AccId);
		return accountMapper.getAccountById(mt940AccId);
	}

	@Override
	public List<Account> getCashGroupAccounts(String groupSname,Integer groupSequence) {
		List<Account> accounts = accountMapper.getCashGroupAccounts(groupSequence);
		return enrichAccountType(accounts, groupSname);
	}

	private List<Account> enrichAccountType(List<Account> accounts, String groupSname) {
		List<AccountInfo> accountInfo = accountMapper.getAccountInfo(groupSname);
		for (Account account : accounts) {
			for (AccountInfo accountInfo2 : accountInfo) {
				if (account.getMt940AcId().trim().equals(accountInfo2.getMt940AcId().trim())) {
					if (accountInfo2.getAccountType().equalsIgnoreCase("C")) {
						account.setAccountTypeStr("Master");
					}
				}
			}
			if (account.getAccountTypeStr() == null) {
				account.setAccountTypeStr("Feeder");
			}
		}

		return accounts;
	}

}
