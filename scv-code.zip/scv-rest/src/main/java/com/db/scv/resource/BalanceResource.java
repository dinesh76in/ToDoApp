package com.db.scv.resource;

import java.io.File;
import java.io.FileWriter;
import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.GenericEntity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.supercsv.io.CsvBeanWriter;
import org.supercsv.io.ICsvBeanWriter;
import org.supercsv.prefs.CsvPreference;

import com.db.scv.mapper.cpe.ProcessControlMapper;
import com.db.scv.model.Account;
import com.db.scv.model.Balance;
import com.db.scv.service.AccountService;
import com.db.scv.service.BalanceService;
import com.db.scv.util.AppUtil;

@Path("/balance")
@Component
public class BalanceResource {

	private static final Logger LOG = LoggerFactory.getLogger(BalanceResource.class);

	@Autowired
	private BalanceService balanceService = null;

	@Autowired
	private AccountService accountService = null;

	@Autowired
	private ProcessControlMapper processControlMapper = null;

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/{groupSname}/{balanceDate}/{action}")
	public Response getClientAccountsBalances(@PathParam("groupSname") String groupSname,
			@PathParam("balanceDate") Integer balanceDate, @PathParam("action") String action) {

		LOG.info(" Fetching Client Account Balances for  - groupSname:" + groupSname + " balanceDate" + balanceDate
				+ " action" + action);
		List<Account> clientAccounts = accountService.getClientAccounts(groupSname);
		String[] accountIds = new String[clientAccounts.size()];

		for (int i = 0; i < clientAccounts.size(); i++) {
			accountIds[i] = clientAccounts.get(i).getMt940AcId();
		}

		List<Balance> balances = balanceService.getBalance(accountIds, balanceDate, action);

		LOG.info(" Balances retrived  -  " + balances.size());
		GenericEntity<List<Balance>> ge = new GenericEntity<List<Balance>>(balances) {
		};
		return Response.ok(ge).build();
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/cashgroup/{groupSname}/{groupSequence}/{balanceDate}/{action}")
	public Response getCashGroupAccountsBalances(@PathParam("groupSname") String groupSname,
			@PathParam("groupSequence") Integer groupSequence, @PathParam("balanceDate") Integer balanceDate,
			@PathParam("action") String action) {

		LOG.info(" Fetching CashGroup Account balances for  - groupSequence:" + groupSequence + " groupSname:"
				+ groupSname + " balanceDate" + balanceDate + " action" + action);

		List<Balance> balances = balanceService.getCashGroupAccountBalances(groupSname, groupSequence, balanceDate,
				action);

		LOG.info(" Balances retrived  -  " + balances.size());
		GenericEntity<List<Balance>> ge = new GenericEntity<List<Balance>>(balances) {
		};
		return Response.ok(ge).build();
	}

	@GET
	@Produces({ "application/ms-excel" })
	@Path("/download/{groupSname}/{numberOfDays}")

	public Response downloadClientAccountBalances(@PathParam("groupSname") String groupSname,
			@PathParam("numberOfDays") Integer numberOfDays) {

		LOG.info(" Downloading "+numberOfDays+" days balances for client "+groupSname);
		List<Account> clientAccounts = accountService.getClientAccounts(groupSname);
		String[] accountIds = new String[clientAccounts.size()];

		for (int i = 0; i < clientAccounts.size(); i++) {
			accountIds[i] = clientAccounts.get(i).getMt940AcId();
		}

		int toDate = processControlMapper.getExecDate();
		int fromDate = AppUtil.getPreviousDate(toDate, numberOfDays);

		List<Balance> balances = balanceService.getBalance(accountIds, fromDate, toDate);

		try {
			ICsvBeanWriter csvWriter = new CsvBeanWriter(new FileWriter("C:/Users/vermdin/Temp/balances.csv"),
					CsvPreference.STANDARD_PREFERENCE);
			String[] header = { "ValueDate", "Mt940Acid", "BalanceDayNet", "BalanceDayCr", "BalanceDayDb",
					"BalanceRealNet", "BalanceRealCr", "BalanceRealDb", "BookBalance" };
			csvWriter.writeHeader(header);
			System.out.println(" Starting to write  ");
			for (Balance balance : balances) {
				csvWriter.write(balance, header);
			}
			System.out.println(" Finished ");
			csvWriter.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

		File file = new File("C:/Users/vermdin/Temp/balances.csv");
		return Response.ok(file, "application/ms-excel")
				.header("Content-Disposition", "attachment;filename=balances.csv").build();
	}

	
	@GET
	@Produces({ "application/ms-excel" })
	@Path("/download/{groupSname}/{groupSequence}/{numberOfDays}")

	public Response downloadCashGroupAccountBalances(@PathParam("groupSname") String groupSname,
			@PathParam("groupSequence") Integer groupSequence,
			@PathParam("numberOfDays") Integer numberOfDays) {

		List<Account> cashGroupAccounts = accountService.getCashGroupAccounts(groupSname, groupSequence);
		String[] accountIds = new String[cashGroupAccounts.size()];

		for (int i = 0; i < cashGroupAccounts.size(); i++) {
			accountIds[i] = cashGroupAccounts.get(i).getMt940AcId();
		}

		int toDate = processControlMapper.getExecDate();
		int fromDate = AppUtil.getPreviousDate(toDate, numberOfDays);

		List<Balance> balances = balanceService.getBalance(accountIds, fromDate, toDate);

		try {
			ICsvBeanWriter csvWriter = new CsvBeanWriter(new FileWriter("C:/Users/vermdin/Temp/balances.csv"),
					CsvPreference.STANDARD_PREFERENCE);
			String[] header = { "ValueDate", "Mt940Acid", "BalanceDayNet", "BalanceDayCr", "BalanceDayDb",
					"BalanceRealNet", "BalanceRealCr", "BalanceRealDb", "BookBalance" };
			csvWriter.writeHeader(header);
			System.out.println(" Starting to write  ");
			for (Balance balance : balances) {
				csvWriter.write(balance, header);
			}
			System.out.println(" Finished ");
			csvWriter.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

		File file = new File("C:/Users/vermdin/Temp/balances.csv");
		return Response.ok(file, "application/ms-excel")
				.header("Content-Disposition", "attachment;filename=balances.csv").build();
	}

	
	
}
