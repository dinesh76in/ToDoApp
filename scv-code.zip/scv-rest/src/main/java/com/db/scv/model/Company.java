package com.db.scv.model;

import java.io.Serializable;
import java.sql.Timestamp;

public class Company implements Serializable {

	private static final long serialVersionUID = -1514703171293902290L;

	private String cmpSname;
	private String cmpLname;
	private String countryCode;
	private String cmpAddr1;
	private String cmpAddr2;
	private String cmpAddr3;
	private String cmpAddr4;
	private String cmpAddr5;
	private String cmpAddr6;
	private String cmpAddr7;
	private String cmpAddr8;
	private String groupSname;
	private String cmpContactPerson;
	private String cmpContactPhone;
	private String cmpContactFax;
	private String cmpContactEmail;
	private Integer insertDate;
	private Integer deleteDate;
	private Integer dataVersionNo;
	private Timestamp changeTimestamp;
	private String changeUserId;
	private String changeMsgCarrierId;
	private String changeCountry;
	private String changeEntity;
	private String changeBranch;
	private Integer changeSequence;

	public String getCmpSname() {
		return cmpSname;
	}

	public void setCmpSname(String cmpSname) {
		this.cmpSname = cmpSname;
	}

	public String getCmpLname() {
		return cmpLname;
	}

	public void setCmpLname(String cmpLname) {
		this.cmpLname = cmpLname;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public String getCmpAddr1() {
		return cmpAddr1;
	}

	public void setCmpAddr1(String cmpAddr1) {
		this.cmpAddr1 = cmpAddr1;
	}

	public String getCmpAddr2() {
		return cmpAddr2;
	}

	public void setCmpAddr2(String cmpAddr2) {
		this.cmpAddr2 = cmpAddr2;
	}

	public String getCmpAddr3() {
		return cmpAddr3;
	}

	public void setCmpAddr3(String cmpAddr3) {
		this.cmpAddr3 = cmpAddr3;
	}

	public String getCmpAddr4() {
		return cmpAddr4;
	}

	public void setCmpAddr4(String cmpAddr4) {
		this.cmpAddr4 = cmpAddr4;
	}

	public String getCmpAddr5() {
		return cmpAddr5;
	}

	public void setCmpAddr5(String cmpAddr5) {
		this.cmpAddr5 = cmpAddr5;
	}

	public String getCmpAddr6() {
		return cmpAddr6;
	}

	public void setCmpAddr6(String cmpAddr6) {
		this.cmpAddr6 = cmpAddr6;
	}

	public String getCmpAddr7() {
		return cmpAddr7;
	}

	public void setCmpAddr7(String cmpAddr7) {
		this.cmpAddr7 = cmpAddr7;
	}

	public String getCmpAddr8() {
		return cmpAddr8;
	}

	public void setCmpAddr8(String cmpAddr8) {
		this.cmpAddr8 = cmpAddr8;
	}

	public String getGroupSname() {
		return groupSname;
	}

	public void setGroupSname(String groupSname) {
		this.groupSname = groupSname;
	}

	public String getCmpContactPerson() {
		return cmpContactPerson;
	}

	public void setCmpContactPerson(String cmpContactPerson) {
		this.cmpContactPerson = cmpContactPerson;
	}

	public String getCmpContactPhone() {
		return cmpContactPhone;
	}

	public void setCmpContactPhone(String cmpContactPhone) {
		this.cmpContactPhone = cmpContactPhone;
	}

	public String getCmpContactFax() {
		return cmpContactFax;
	}

	public void setCmpContactFax(String cmpContactFax) {
		this.cmpContactFax = cmpContactFax;
	}

	public String getCmpContactEmail() {
		return cmpContactEmail;
	}

	public void setCmpContactEmail(String cmpContactEmail) {
		this.cmpContactEmail = cmpContactEmail;
	}

	public Integer getInsertDate() {
		return insertDate;
	}

	public void setInsertDate(Integer insertDate) {
		this.insertDate = insertDate;
	}

	public Integer getDeleteDate() {
		return deleteDate;
	}

	public void setDeleteDate(Integer deleteDate) {
		this.deleteDate = deleteDate;
	}

	public Integer getDataVersionNo() {
		return dataVersionNo;
	}

	public void setDataVersionNo(Integer dataVersionNo) {
		this.dataVersionNo = dataVersionNo;
	}

	public Timestamp getChangeTimestamp() {
		return changeTimestamp;
	}

	public void setChangeTimestamp(Timestamp changeTimestamp) {
		this.changeTimestamp = changeTimestamp;
	}

	public String getChangeUserId() {
		return changeUserId;
	}

	public void setChangeUserId(String changeUserId) {
		this.changeUserId = changeUserId;
	}

	public String getChangeMsgCarrierId() {
		return changeMsgCarrierId;
	}

	public void setChangeMsgCarrierId(String changeMsgCarrierId) {
		this.changeMsgCarrierId = changeMsgCarrierId;
	}

	public String getChangeCountry() {
		return changeCountry;
	}

	public void setChangeCountry(String changeCountry) {
		this.changeCountry = changeCountry;
	}

	public String getChangeEntity() {
		return changeEntity;
	}

	public void setChangeEntity(String changeEntity) {
		this.changeEntity = changeEntity;
	}

	public String getChangeBranch() {
		return changeBranch;
	}

	public void setChangeBranch(String changeBranch) {
		this.changeBranch = changeBranch;
	}

	public Integer getChangeSequence() {
		return changeSequence;
	}

	public void setChangeSequence(Integer changeSequence) {
		this.changeSequence = changeSequence;
	}

}
