package com.db.scv.mapper.cpe;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.SelectProvider;

import com.db.scv.mapper.provider.BalanceSelectProvider;
import com.db.scv.model.Balance;

public interface BalanceMapper {

	@SelectProvider(type = BalanceSelectProvider.class, method = "getBalances")
	 @Results(value = {
   	      @Result(property = "valueDate", column = "VALUE_DATE"),
   	      @Result(property = "mt940Acid", column = "MT940_ACC_ID"),
   	      @Result(property = "balanceDayNet", column = "BALANCE_DAY_NET"),
   	      @Result(property = "balanceDayCr", column = "BALANCE_DAY_CR"),       
   	      @Result(property = "balanceDayDb", column = "BALANCE_DAY_DB"),
   	      @Result(property = "balanceRealNet", column = "BALANCE_REAL_NET"),
   	      @Result(property = "balanceRealCr", column = "BALANCE_REAL_CR"),
   	      @Result(property = "balanceRealDb", column = "BALANCE_REAL_DB"),
   	      @Result(property = "bookBalance", column = "BOOK_BALANCE"),
   	      @Result(property = "currencyCode", column = "CURRENCY_CODE"),       
   	      @Result(property = "dataVersionNo", column = "DATA_VERSION_NO"),
   	      @Result(property = "changeTimeStamp", column = "CHANGE_TS"),
   	      @Result(property = "changeUserId", column = "CHANGE_USERID"),
   	      @Result(property = "changeMsgCarrierId", column = "CHG_MESS_CARR_ID"),
   	      @Result(property = "changeCountry", column = "CHANGE_COUNTRY"),       
   	      @Result(property = "changeEntity", column = "CHANGE_ENTITY"),
   	      @Result(property = "changeBranch", column = "CHANGE_BRANCH")
   	   })
	  public List<Balance> getBalance(@Param("mt940AccIds") String[] mt940AccIds,@Param("execDate") Integer execDate,@Param("fromDate") Integer fromDate,@Param("toDate") Integer toDate);
	
	
	
	
}

