package com.db.scv.mapper.cpe;

import org.apache.ibatis.annotations.Select;

public interface ProcessControlMapper {


	@Select("select PZ030T.EXEC_DATE from PZ030T where PZ030T.code_process = 'PZ000'")
	 public Integer getExecDate();

}
