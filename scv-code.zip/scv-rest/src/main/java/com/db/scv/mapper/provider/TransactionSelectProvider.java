package com.db.scv.mapper.provider;

import java.util.Map;

public class TransactionSelectProvider {
	private static final String COMMA = ",";
	private static final String BRACE = "'";

	public String getTransactions(Map parameters) {

		String[] mt940AccIds = (String[]) parameters.get("mt940AccIds");

		StringBuilder query = new StringBuilder();
		query.append("Select * from PZ020T where SOURCE_MT940_ACC in (");

		if(mt940AccIds.length==0){
			query.append(BRACE+" "+BRACE+")");
		}
		for (String element : mt940AccIds) {
			query.append(BRACE + element + BRACE + COMMA);
		}
		query.delete(query.length() - 1, query.length());
		query.append(")");

		System.out.println(" Ordered Transactions Query " + query.toString());
		return query.toString();
	}
}
