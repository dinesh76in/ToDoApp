package com.db.scv.service;

import java.util.List;

import com.db.scv.model.Company;

public interface CompanyService {

	public List<Company> getClientCompanies(String groupSname);
	
	public Company getCompany(String cmpnySname);
}
