package com.db.scv.mapper.cpe;

import java.util.List;

import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;

import com.db.scv.model.Product;

public interface ProductMapper {

	@Select("Select * from PZ083T where product_seq in (Select distinct Product_seq from PZ005T  where GROUP_SNAME like '%'||#{groupSname}||'%'   )")
	@Results(value = { @Result(property = "name", column = "NAME"),
			@Result(property = "cashMeth", column = "CASH_METH"),
			@Result(property = "productCalender", column = "PRODUCT_CALENDAR"),
			@Result(property = "branchCalender", column = "BRANCH_CALENDAR"),
			@Result(property = "accMethod", column = "ACC_METHOD")

	})
	public List<Product> getProductsByClient(String groupSname);

	@Select("Select * from PZ083T")
	@Results(value = { @Result(property = "name", column = "NAME"),
			@Result(property = "cashMeth", column = "CASH_METH"),
			@Result(property = "productCalender", column = "PRODUCT_CALENDAR"),
			@Result(property = "branchCalender", column = "BRANCH_CALENDAR"),
			@Result(property = "accMethod", column = "ACC_METHOD")

	})
	public List<Product> getAllProducts();

}
