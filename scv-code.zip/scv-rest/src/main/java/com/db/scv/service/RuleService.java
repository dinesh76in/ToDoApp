package com.db.scv.service;

import java.util.List;

import com.db.scv.model.Rule;

public interface RuleService {
	
	public List<Rule> getCashGroupRules(Integer groupSequence);

}
