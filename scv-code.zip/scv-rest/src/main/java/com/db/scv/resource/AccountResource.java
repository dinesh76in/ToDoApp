package com.db.scv.resource;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.GenericEntity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.db.scv.model.Account;
import com.db.scv.service.AccountService;

@Path("/account")
@Component
public class AccountResource {

	private static final Logger LOG = LoggerFactory.getLogger(CompanyGroupResource.class);

	@Autowired
	private AccountService accountService = null;

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/client/{groupSname}")
	public Response getClientAccounts(@PathParam("groupSname")String groupSname) {
		LOG.info(" Fetching list of clients ");
		List<Account> clientsAccounts = accountService.getClientAccounts(groupSname);

		LOG.info(" Number of clients accounts fetched -  " + clientsAccounts.size());
		GenericEntity<List<Account>> ge = new GenericEntity<List<Account>>(clientsAccounts) {};
		return Response.ok(ge).build();
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/cashgroup/{groupSname}/{groupSequence}")
	public Response getCashGroupAccounts(@PathParam("groupSname")String groupSname,@PathParam("groupSequence")Integer groupSequence) {
		LOG.info(" Fetching list of accounts for cash group sequence "+groupSequence);
		List<Account> cashGroupAccounts = accountService.getCashGroupAccounts(groupSname,groupSequence);

		LOG.info(" Number of  accounts fetched -  " + cashGroupAccounts.size());
		GenericEntity<List<Account>> ge = new GenericEntity<List<Account>>(cashGroupAccounts) {};
		return Response.ok(ge).build();
	}
	
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
    @Path("/company/{groupSname}/{cmpnySname}")
	public Response getCompanyAccounts(@PathParam("groupSname")String groupSname,@PathParam("cmpnySname")String cmpnySname) {
		LOG.info(" Fetching accounts for company  "+cmpnySname);
		List<Account> companyAccounts = accountService.getCompanyAccounts(groupSname,cmpnySname);

		LOG.info(" Number of accounts fetched -  " + companyAccounts.size());
		GenericEntity<List<Account>> ge = new GenericEntity<List<Account>>(companyAccounts) {};
		return Response.ok(ge).build();
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
    @Path("/{accSequence}")
	public Response getAccountBySequence(@PathParam("accSequence")Integer accSequence) {
		LOG.info(" Fetching account for accSequence  "+accSequence);
		Account account = accountService.getAccountBySequence(accSequence);

		GenericEntity<Account> ge = new GenericEntity<Account>(account) {};
		return Response.ok(ge).build();
	}

}
