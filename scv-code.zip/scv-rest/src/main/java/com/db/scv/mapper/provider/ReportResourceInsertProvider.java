package com.db.scv.mapper.provider;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import oracle.sql.BLOB;

public class ReportResourceInsertProvider {

	private static final Logger LOG = LoggerFactory.getLogger(ReportResourceInsertProvider.class);

	private static final String COMMA = ",";
	private static final String BRACE = "'";
	private static final String QUOTE = "'";

	public static String insertReportResource(Map parameters) {

		
		LOG.info(parameters.toString());
		
		int id = (Integer) parameters.get("id");
		int reportId = (Integer) parameters.get("reportId");
		String name = (String) parameters.get("name");
		String description = (String) parameters.get("description");
		String type = (String) parameters.get("type");
		String data = (String) parameters.get("data");

		StringBuilder query = new StringBuilder();
		query.append("insert into REPORT_RESOURCE (id,report_id,name,description,type,data) VALUES  (");

		query.append(id + COMMA);
		query.append(reportId + COMMA);

		query.append(BRACE + name + BRACE + COMMA);
		query.append(BRACE + description + BRACE + COMMA);
		query.append(BRACE + type + BRACE + COMMA);

		query.append("utl_raw.cast_to_raw(");

		query.append(BRACE + data + BRACE);

		query.append(")");
		query.append(")");

		System.out.println(query.toString());

		return query.toString();
	}

	/*public static void main(String args[]) {

		Map<String, Object> parameters = new HashMap<String, Object>();

		parameters.put("id", 5);
		parameters.put("reportId", 4);
		parameters.put("name", "file");
		parameters.put("data", "<xml>this is test data <xml>");
		
		BLOB blob=new Blob

		insertReportResource(parameters);

	}*/

}
