package com.db.scv.model;

public class Product {

	private String name;
	private String cashMeth;
	private String productCalender;
	private String branchCalender;
	private String accMethod;
	private String autoRecall;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCashMeth() {
		return cashMeth;
	}
	public void setCashMeth(String cashMeth) {
		this.cashMeth = cashMeth;
	}
	public String getProductCalender() {
		return productCalender;
	}
	public void setProductCalender(String productCalender) {
		this.productCalender = productCalender;
	}
	public String getBranchCalender() {
		return branchCalender;
	}
	public void setBranchCalender(String branchCalender) {
		this.branchCalender = branchCalender;
	}
	public String getAccMethod() {
		return accMethod;
	}
	public void setAccMethod(String accMethod) {
		this.accMethod = accMethod;
	}
	public String getAutoRecall() {
		return autoRecall;
	}
	public void setAutoRecall(String autoRecall) {
		this.autoRecall = autoRecall;
	}

	
}
