package com.db.scv.model;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

public class AccountInfo {
	private String mt940AcId;
	private String accountType;
	public String getMt940AcId() {
		return mt940AcId;
	}
	public void setMt940AcId(String mt940AcId) {
		this.mt940AcId = mt940AcId;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	
	public String toString(){
		return ReflectionToStringBuilder.toString(this);

	}
	
}
