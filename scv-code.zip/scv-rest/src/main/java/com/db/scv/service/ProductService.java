package com.db.scv.service;

import java.util.List;

import com.db.scv.model.Product;

public interface ProductService {

	  public List<Product> getProductsByClient(String groupSname);
	  
	  public List<Product> getAllProdcuts();
}
