package com.db.scv.mapper.cpe;

import java.util.List;

import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;

import com.db.scv.model.AccountsByCashGroup;

public interface AccountsByCashGroupMapper {
	 @Select("Select * from Pz009T where group_sequence =#{groupSequence}")
     @Results(value = {
   	      @Result(property = "mt940AccId", column = "MT940_ACC_ID"),
   	      @Result(property = "groupSequence", column = "GROUP_SEQUENCE"),
   	      @Result(property = "startDate", column = "START_DATE"),
   	      @Result(property = "endDate", column = "END_DATE"),       
   	      @Result(property = "accRelation", column = "ACC_RELATION"),       
   	      @Result(property = "firstTransacDay", column = "FIRST_TRANSAC_DAY"),
   	      @Result(property = "lastTransacDay", column = "LAST_TRANSAC_DAY"),
   	      @Result(property = "lastTransac", column = "LAST_TRANSAC"),
   	      @Result(property = "lastTransacSimul", column = "LAST_TRANSAC_SIMUL"),
   	      @Result(property = "firstForecast", column = "FIRST_FORECAST"),  
   	      @Result(property = "insertDate", column = "INSERT_DATE"),       
	      @Result(property = "deleteDate", column = "DELETE_DATE"),
	      /* @Result(property = "ruleSequence", column = "RULE_SEQUENCE"),  
	      @Result(property = "dataVersionNo", column = "DATA_VERSION_NO"),
	      @Result(property = "changeTimestamp", column = "CHANGE_TS"),
	      @Result(property = "changeUserId", column = "CHANGE_USERID"),
	      @Result(property = "changeMsgCarrierId", column = "CHG_MESS_CARR_ID"),   
   	      @Result(property = "changeCountry", column = "CHANGE_COUNTRY"),
   	      @Result(property = "changeEntity", column = "CHANGE_ENTITY"),
   	      @Result(property = "changeBranch", column = "CHANGE_BRANCH"), 	
   	      @Result(property = "changeSequence", column = "CHANGE_SEQUENCE"),  
 	      @Result(property = "flagAlert", column = "FLAG_ALERT"),*/
          @Result(property = "procBranch", column = "PROC_BRANCH")
   	   })
	  public List<AccountsByCashGroup> getCashGroupAccounts(Integer groupSequence);
}
