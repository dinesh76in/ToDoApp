package com.db.scv.resource;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.GenericEntity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.db.scv.model.CompanyGroup;
import com.db.scv.service.CompanyGroupService;

@Path("/companygroup")
@Component
public class CompanyGroupResource {

	private static final Logger LOG = LoggerFactory.getLogger(CompanyGroupResource.class);

	@Autowired
	private CompanyGroupService companyGroupService = null;

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public Response getCompanyGroups() {
		LOG.info(" Fetching list of clients ");
		List<CompanyGroup> clientsList = companyGroupService.getCompanyGroups();

		LOG.info(" Number of clients fetched -  " + clientsList.size());
		GenericEntity<List<CompanyGroup>> ge = new GenericEntity<List<CompanyGroup>>(clientsList) {};
		return Response.ok(ge).build();
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
    @Path("{groupSname}")
	public Response getCompanyGroup(@PathParam("groupSname")String groupSname) {
		LOG.info(" Fetching details for client  "+groupSname);
		CompanyGroup client = companyGroupService.getCompanyGroup(groupSname);

		LOG.info(" Client Details -  " + client);
		GenericEntity<CompanyGroup> ge = new GenericEntity<CompanyGroup>(client) {};
		return Response.ok(ge).build();
	}
	
}
