package com.db.scv.service;

import java.util.List;

import com.db.scv.model.Balance;

public interface BalanceService {

	public List<Balance>  getBalance(String[] mt940AccIds, Integer balanceDate, String action);
	
	public List<Balance>  getBalance(String[] mt940AccIds, Integer fromDate, Integer toDate);

	public List<Balance> getCashGroupAccountBalances(String groupSname,Integer groupSequence,  Integer balanceDate,
			String action);

}
