package com.db.scv.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.db.scv.mapper.cpe.CompanyGroupMapper;
import com.db.scv.model.CompanyGroup;
import com.db.scv.service.CompanyGroupService;

@Component
@Service
public class CompanyGroupServiceImpl implements CompanyGroupService {

	private static final Logger LOG = LoggerFactory.getLogger(CompanyGroupServiceImpl.class);

	@Autowired
	private CompanyGroupMapper companyGroupMapper = null;

	public List<CompanyGroup> getCompanyGroups() {
		return companyGroupMapper.getAll();
	}

	public CompanyGroup getCompanyGroup(String groupSname) {
		return companyGroupMapper.getCompanyGroup(groupSname);
	}

}
