package com.db.scv.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.db.scv.mapper.cpe.CashGroupMapper;
import com.db.scv.model.CashGroup;
import com.db.scv.service.CashGroupService;

@Component
@Service
public class CashGroupServiceImpl implements CashGroupService{
	
	private static final Logger LOG = LoggerFactory.getLogger(CashGroupServiceImpl.class);

	@Autowired
	private CashGroupMapper  cashGroupMapper = null;
	

	@Override
	public List<CashGroup> getClientCashGroups(String groupSname){
		return cashGroupMapper.getClientCashGroups(groupSname);
	}

	@Override
	public CashGroup getCashGroupById(Integer groupSequence) {
		return cashGroupMapper.getCashGroupById(groupSequence);
	}

}
