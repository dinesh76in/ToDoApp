package com.db.scv.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.db.scv.mapper.cpe.OrderedTransactionMapper;
import com.db.scv.model.Account;
import com.db.scv.model.OrderedTransaction;
import com.db.scv.service.AccountService;
import com.db.scv.service.TransactionService;

@Component
@Service
public class TransactionServiceImpl implements TransactionService {

	private static final Logger LOG = LoggerFactory.getLogger(TransactionServiceImpl.class);

	@Autowired
	private OrderedTransactionMapper orderedTransactionMapper = null;

	@Autowired
	private AccountService accountService = null;

	@Override
	public List<OrderedTransaction> getClientAccountsTransactions(String groupSname) {
		LOG.info(" Fetching transactions for groupSname: " + groupSname);
		List<Account> accounts = accountService.getClientAccounts(groupSname);
		return orderedTransactionMapper.getTransactions(extractAccountIds(accounts));
	}

	@Override
	public List<OrderedTransaction> getCashGroupAccountsTransactions(String groupSname, Integer groupSequence) {

		LOG.info(" Fetching transactions for groupSname: " + groupSname + " groupSequence:" + groupSequence);
		List<Account> cashGroupAccounts = accountService.getCashGroupAccounts(groupSname, groupSequence);

		return orderedTransactionMapper.getTransactions(extractAccountIds(cashGroupAccounts));
	}

	private String[] extractAccountIds(List<Account> accounts) {
		return accounts.stream().map(Account::getMt940AcId).collect(Collectors.toList()).toArray(new String[accounts.size()]);
	}

}
