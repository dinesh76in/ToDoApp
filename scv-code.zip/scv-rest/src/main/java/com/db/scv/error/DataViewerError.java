package com.db.scv.error;

public class DataViewerError extends RuntimeException {

	private static final long serialVersionUID = 2133775731088933739L;
	private String exceptionMsg;

	public DataViewerError(String exceptionMsg) {
		this.exceptionMsg = exceptionMsg;
	}

	public String getExceptionMsg() {
		return this.exceptionMsg;
	}

	public void setExceptionMsg(String exceptionMsg) {
		this.exceptionMsg = exceptionMsg;
	}

}
