package com.db.scv.resource;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.GenericEntity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.db.scv.model.OrderedTransaction;
import com.db.scv.service.TransactionService;

@Path("/transaction")
@Component
public class TransactionResource {
	
	private static final Logger LOG = LoggerFactory.getLogger(TransactionResource.class);
	
	@Autowired
	private TransactionService transactionService = null;
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/cashgroup/{groupSname}/{groupSequence}")
	public Response getCashGroupAccountsTransactions(@PathParam("groupSname")String groupSname,
			@PathParam("groupSequence")Integer groupSequence) {
		LOG.info(" Fetching list of transactions for cash group sequence "+groupSequence);
		List<OrderedTransaction> cashGroupAccountsTransactions = transactionService.getCashGroupAccountsTransactions(groupSname,groupSequence);

		LOG.info(" Number of cashgroup transactions fetched -  " + cashGroupAccountsTransactions.size());
		GenericEntity<List<OrderedTransaction>> ge = new GenericEntity<List<OrderedTransaction>>(cashGroupAccountsTransactions) {};
		return Response.ok(ge).build();
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/client/{groupSname}")
	public Response getCashGroupAccounts(@PathParam("groupSname")String groupSname) {
		LOG.info(" Fetching list of transactions for groupSname "+groupSname);
		List<OrderedTransaction> clientTransactions = transactionService.getClientAccountsTransactions(groupSname);

		LOG.info(" Number of  client transactions fetched -  " + clientTransactions.size());
		GenericEntity<List<OrderedTransaction>> ge = new GenericEntity<List<OrderedTransaction>>(clientTransactions) {};
		return Response.ok(ge).build();
	}
}
