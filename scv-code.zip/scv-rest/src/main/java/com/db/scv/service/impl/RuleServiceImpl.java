package com.db.scv.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.db.scv.mapper.cpe.RuleMapper;
import com.db.scv.model.Rule;
import com.db.scv.service.RuleService;

@Component
@Service
public class RuleServiceImpl implements RuleService {

	@Autowired
	private RuleMapper ruleMapper = null;

	@Override
	public List<Rule> getCashGroupRules(Integer groupSequence) {

		return ruleMapper.getRulesForCashGroup(groupSequence);
	}

}
