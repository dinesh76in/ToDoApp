package com.db.scv.model;

import java.sql.Timestamp;

import com.db.scv.util.AppUtil;

public class CashGroup {
	
	private Integer groupSequence;
	private String groupSname;
	private String cashGroupSname;
	private String cashGroupLname;
	private Integer startDate;
	private Integer endDate;
	private String cashMeth;
	private String cashMethDesc;

	private Integer groupOrder;
	private String flagForcedExec;
	private String baseCurrency;
	private String groupStatus;
	private Integer futureValues;
	private Integer backValuesCredit;
	private Integer backValuesDebit;
	private String flagSimulation;
	private Integer productionDate;
	private Integer firstSettleDate;
	private Integer insertDate;
	private Integer deleteDate;
	private Integer dataVersionNo;
	private Timestamp changeTimestamp;
	private String changeUserId;
	private String changeMsgCarrierId;
	private String changeCountry;
	private Integer changeEntity;
	private Integer changeBranch;
	private String distributePolicy;
	private Integer accountDistribut;
	private Integer dayBase;
	private String distrPolicyNeg;
	private Integer accountDistrNeg;
	private Integer nextSettleDate;
	private String continentalType;
	private Integer changeSequence;
	private String xgtmFlag;
	private String xgtmIdentity;
	private Integer xgtmStartDate;
	private Integer xgtmEndDate;
	private String opsTeam;
	private String procBranch;
	private Integer productSeq;
	private String processingType;
	public Integer getGroupSequence() {
		return groupSequence;
	}
	public void setGroupSequence(Integer groupSequence) {
		this.groupSequence = groupSequence;
	}
	public String getGroupSname() {
		return groupSname;
	}
	public void setGroupSname(String groupSname) {
		this.groupSname = groupSname;
	}
	public String getCashGroupSname() {
		return cashGroupSname;
	}
	public void setCashGroupSname(String cashGroupSname) {
		this.cashGroupSname = cashGroupSname;
	}
	public String getCashGroupLname() {
		return cashGroupLname;
	}
	public void setCashGroupLname(String cashGroupLname) {
		this.cashGroupLname = cashGroupLname;
	}
	public Integer getStartDate() {
		return startDate;
	}
	public void setStartDate(Integer startDate) {
		this.startDate = startDate;
	}
	public Integer getEndDate() {
		return endDate;
	}
	public void setEndDate(Integer endDate) {
		this.endDate = endDate;
	}
	public String getCashMeth() {
		return cashMeth;
	}
	public void setCashMeth(String cashMeth) {
		this.cashMeth = cashMeth;
	}
	public Integer getGroupOrder() {
		return groupOrder;
	}
	public void setGroupOrder(Integer groupOrder) {
		this.groupOrder = groupOrder;
	}
	public String getFlagForcedExec() {
		return flagForcedExec;
	}
	public void setFlagForcedExec(String flagForcedExec) {
		this.flagForcedExec = flagForcedExec;
	}
	public String getBaseCurrency() {
		return baseCurrency;
	}
	public void setBaseCurrency(String baseCurrency) {
		this.baseCurrency = baseCurrency;
	}
	public String getGroupStatus() {
		return groupStatus;
	}
	public void setGroupStatus(String groupStatus) {
		this.groupStatus = groupStatus;
	}
	public Integer getFutureValues() {
		return futureValues;
	}
	public void setFutureValues(Integer futureValues) {
		this.futureValues = futureValues;
	}
	public Integer getBackValuesCredit() {
		return backValuesCredit;
	}
	public void setBackValuesCredit(Integer backValuesCredit) {
		this.backValuesCredit = backValuesCredit;
	}
	public Integer getBackValuesDebit() {
		return backValuesDebit;
	}
	public void setBackValuesDebit(Integer backValuesDebit) {
		this.backValuesDebit = backValuesDebit;
	}
	public String getFlagSimulation() {
		return flagSimulation;
	}
	public void setFlagSimulation(String flagSimulation) {
		this.flagSimulation = flagSimulation;
	}
	public Integer getProductionDate() {
		return productionDate;
	}
	public void setProductionDate(Integer productionDate) {
		this.productionDate = productionDate;
	}
	public Integer getFirstSettleDate() {
		return firstSettleDate;
	}
	public void setFirstSettleDate(Integer firstSettleDate) {
		this.firstSettleDate = firstSettleDate;
	}
	public Integer getInsertDate() {
		return insertDate;
	}
	public void setInsertDate(Integer insertDate) {
		this.insertDate = insertDate;
	}
	public Integer getDeleteDate() {
		return deleteDate;
	}
	public void setDeleteDate(Integer deleteDate) {
		this.deleteDate = deleteDate;
	}
	public Integer getDataVersionNo() {
		return dataVersionNo;
	}
	public void setDataVersionNo(Integer dataVersionNo) {
		this.dataVersionNo = dataVersionNo;
	}
	public Timestamp getChangeTimestamp() {
		return changeTimestamp;
	}
	public void setChangeTimestamp(Timestamp changeTimestamp) {
		this.changeTimestamp = changeTimestamp;
	}
	public String getChangeUserId() {
		return changeUserId;
	}
	public void setChangeUserId(String changeUserId) {
		this.changeUserId = changeUserId;
	}
	public String getChangeMsgCarrierId() {
		return changeMsgCarrierId;
	}
	public void setChangeMsgCarrierId(String changeMsgCarrierId) {
		this.changeMsgCarrierId = changeMsgCarrierId;
	}
	public String getChangeCountry() {
		return changeCountry;
	}
	public void setChangeCountry(String changeCountry) {
		this.changeCountry = changeCountry;
	}
	public Integer getChangeEntity() {
		return changeEntity;
	}
	public void setChangeEntity(Integer changeEntity) {
		this.changeEntity = changeEntity;
	}
	public Integer getChangeBranch() {
		return changeBranch;
	}
	public void setChangeBranch(Integer changeBranch) {
		this.changeBranch = changeBranch;
	}
	public String getDistributePolicy() {
		return distributePolicy;
	}
	public void setDistributePolicy(String distributePolicy) {
		this.distributePolicy = distributePolicy;
	}
	public Integer getAccountDistribut() {
		return accountDistribut;
	}
	public void setAccountDistribut(Integer accountDistribut) {
		this.accountDistribut = accountDistribut;
	}
	public Integer getDayBase() {
		return dayBase;
	}
	public void setDayBase(Integer dayBase) {
		this.dayBase = dayBase;
	}
	public String getDistrPolicyNeg() {
		return distrPolicyNeg;
	}
	public void setDistrPolicyNeg(String distrPolicyNeg) {
		this.distrPolicyNeg = distrPolicyNeg;
	}
	public Integer getAccountDistrNeg() {
		return accountDistrNeg;
	}
	public void setAccountDistrNeg(Integer accountDistrNeg) {
		this.accountDistrNeg = accountDistrNeg;
	}
	public Integer getNextSettleDate() {
		return nextSettleDate;
	}
	public void setNextSettleDate(Integer nextSettleDate) {
		this.nextSettleDate = nextSettleDate;
	}
	public String getContinentalType() {
		return continentalType;
	}
	public void setContinentalType(String continentalType) {
		this.continentalType = continentalType;
	}
	public Integer getChangeSequence() {
		return changeSequence;
	}
	public void setChangeSequence(Integer changeSequence) {
		this.changeSequence = changeSequence;
	}
	public String getXgtmFlag() {
		return xgtmFlag;
	}
	public void setXgtmFlag(String xgtmFlag) {
		this.xgtmFlag = xgtmFlag;
	}
	public String getXgtmIdentity() {
		return xgtmIdentity;
	}
	public void setXgtmIdentity(String xgtmIdentity) {
		this.xgtmIdentity = xgtmIdentity;
	}
	public Integer getXgtmStartDate() {
		return xgtmStartDate;
	}
	public void setXgtmStartDate(Integer xgtmStartDate) {
		this.xgtmStartDate = xgtmStartDate;
	}
	public Integer getXgtmEndDate() {
		return xgtmEndDate;
	}
	public void setXgtmEndDate(Integer xgtmEndDate) {
		this.xgtmEndDate = xgtmEndDate;
	}
	public String getOpsTeam() {
		return opsTeam;
	}
	public void setOpsTeam(String opsTeam) {
		this.opsTeam = opsTeam;
	}
	public String getProcBranch() {
		return procBranch;
	}
	public void setProcBranch(String procBranch) {
		this.procBranch = procBranch;
	}
	public Integer getProductSeq() {
		return productSeq;
	}
	public void setProductSeq(Integer productSeq) {
		this.productSeq = productSeq;
	}
	public String getProcessingType() {
		return processingType;
	}
	public void setProcessingType(String processingType) {
		this.processingType = processingType;
	}
	
	public String getCashMethDesc() {
		setCashMethDesc(AppUtil.getCashMethDesc(getCashMeth()));
		return cashMethDesc;
	}
	public void setCashMethDesc(String cashMethDesc) {
		this.cashMethDesc = cashMethDesc;
	}
	
	

}
