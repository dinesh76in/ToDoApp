/*package com.db.scv.service.impl;

import java.io.InputStream;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.jfree.util.Log;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ReportResourceDao {
	
	private static final Logger LOG = LoggerFactory.getLogger(ReportResourceDao.class);


	private static String url = "jdbc:oracle:thin:@FRLIQ1D.DE.DB.COM:1825/FRLIQ1D.DE.DB.COM";
	private static String username = "vermdin";
	private static String password = "Root*123";

	public static void storeReportResource(String name, String description, String type,String data) throws Exception {
		Connection conn = null;
		InputStream fis = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection(url, username, password);
			conn.setAutoCommit(true);

			Clob blob = conn.createClob();
			blob.setString(1l, data);

			String sql = "INSERT INTO REPORT_RESOURCE VALUES (?, ?, ?,?,?,?)";
			PreparedStatement stmt = conn.prepareStatement(sql);
			stmt.setInt(1, geResourceId(conn));
			stmt.setInt(2, getLastReportId(conn));

			stmt.setString(3, name);
			stmt.setString(4, description);
			stmt.setString(5, type);
			stmt.setClob(6, blob);
			stmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (fis != null) {
				fis.close();
			}
			if (conn != null && !conn.isClosed()) {
				conn.close();
			}
		}
	}

	public static void deleteResource(int reportId) throws Exception {
		Connection conn = getReportDbConnection();
		String deleteSql = "delete from REPORT_RESOURCE where report_id=" + reportId + "";
		PreparedStatement stmt = conn.prepareStatement(deleteSql);
		stmt.executeUpdate();
		closeDbConnection(conn);

	}

	private static int getLastReportId(Connection conn) throws Exception {
		String selectSQL = "select max(id) from report";
		PreparedStatement stmt = conn.prepareStatement(selectSQL);
		ResultSet resultSet = stmt.executeQuery();
		resultSet.next();
		int reportId = resultSet.getInt(1);
		
		Log.info("Returning reportId - "+reportId);
		
		return reportId;
	}

	
	private static int geResourceId(Connection conn) throws Exception {
		String selectSQL = "select report_seq.nextval from dual";
		PreparedStatement stmt = conn.prepareStatement(selectSQL);
		ResultSet resultSet = stmt.executeQuery();
		resultSet.next();
		int resourceId = resultSet.getInt(1);
		
		LOG.info(" generated resourceId - "+resourceId);
		return resourceId;
	}
	
	
	public static String getReportXmlFile(int reportId) throws Exception {
		
		String reportXml=null;
		Connection conn =getReportDbConnection();
		
		String selectSQL = "Select Report_Resource.data from Report_Resource where report_Id='"+reportId+"'";
		PreparedStatement stmt = conn.prepareStatement(selectSQL);
		ResultSet resultSet = stmt.executeQuery();
		resultSet.next();
		reportXml=resultSet.getString(1);
		closeDbConnection(conn);

		return reportXml;
		
	}

	private static Connection getReportDbConnection() {
		Connection conn = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection(url, username, password);
			conn.setAutoCommit(true);

		} catch (Exception e) {
			e.printStackTrace();
		}

		return conn;
	}

	private static void closeDbConnection(Connection conn) {

		try {
			if (conn != null && !conn.isClosed()) {
				conn.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static Connection getOracleDBConnection() {
		Connection conn = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@FRLIQ4U.DE.DB.COM:1725/FRLIQ4U.DE.DB.COM", "LPCP_UAT1_OWNER", "Temp#1234");
			conn.setAutoCommit(true);

		} catch (Exception e) {
			e.printStackTrace();
		}

		return conn;
	}  


}
*/