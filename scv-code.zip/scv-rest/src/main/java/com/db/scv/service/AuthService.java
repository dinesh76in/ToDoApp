package com.db.scv.service;

import com.db.scv.model.ScvUser;

public interface AuthService {
	
	public ScvUser authenticate(String userId,String userPassword);

}
