package com.db.scv.util;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

import javax.naming.Context;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.codehaus.jackson.map.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AppUtil {

	private static final Logger LOG = LoggerFactory.getLogger(AppUtil.class);
	private static ObjectMapper MAPPER = new ObjectMapper();

	public static <T> T readAsObjectOf(Class<T> clazz, String value) throws Exception {
		try {
			return MAPPER.readValue(value, clazz);
		} catch (Exception e) {
			LOG.error("Error reading value as Object returning null : " + clazz.getName() + " - " + value, e);
			return null;
		}
	}

	public static Response sendInternalServerErrorResponse() {
		return Response.status(Status.INTERNAL_SERVER_ERROR).entity("Server encountered an error ").build();
	}

	public static Response sendSuccessResponse() {
		return Response.status(200).build();
	}

	public static int getNextDate(Integer inputDate, String action) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		Calendar c = Calendar.getInstance();
		try {
			c.setTime(sdf.parse(String.valueOf(inputDate)));
		} catch (Exception e) {
			e.printStackTrace();
		}

		if (action.equals("next")) {
			c.add(Calendar.DATE, 1);
		} else if (action.equals("prev")) {
			c.add(Calendar.DATE, -1);
		}
		return Integer.valueOf(sdf.format(c.getTime()));
	}

	
	
	public static int getPreviousDate(Integer inputDate, int noOfDays) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		Calendar c = Calendar.getInstance();
		try {
			c.setTime(sdf.parse(String.valueOf(inputDate)));
		} catch (Exception e) {
			e.printStackTrace();
		}
		c.add(Calendar.DATE, -noOfDays);
		
		return Integer.valueOf(sdf.format(c.getTime()));
	}

	
	
	
	public static String getCashMethDesc(String code) {

		Map<String, String> cashMethods = new HashMap<String, String>();
		cashMethods.put("BP", "Pooling of Pools");
		cashMethods.put("BT", "Bankers Trust");
		cashMethods.put("CO", "Conditional");
		cashMethods.put("DP", "Domestic Pool");
		cashMethods.put("IC", "Interest Compensation");
		cashMethods.put("II", "Intraday Investments");
		cashMethods.put("IO", "Interest Optimization");
		cashMethods.put("IR", "Interest Opt. Rockwell");
		cashMethods.put("LR", "Liquidity Report");
		cashMethods.put("OA", "Int Opt Credit Balance");
		cashMethods.put("SA", "Single Account");
		cashMethods.put("ZB", "Zero Balancing");
		return cashMethods.get(code);
	}

	
	
	
	
	public static void main(String args[]){
		
		
		
	}
	
	private static boolean authenticate() {
		try {
			Hashtable<String, String> env = new Hashtable<String, String>();
			env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
			env.put(Context.PROVIDER_URL, "ldap://ldap_server:389");
			//
			env.put(Context.SECURITY_AUTHENTICATION, "simple");
			env.put(Context.SECURITY_PRINCIPAL, "domain\\user"); 
			
			env.put(Context.SECURITY_CREDENTIALS, "test");

			// Create the initial context

			DirContext ctx = new InitialDirContext(env);
			boolean result = ctx != null;

			if (ctx != null)
				ctx.close();

			return result;
		} catch (Exception e) {
			
			e.printStackTrace();
			return false;
		}
	}
	
	
	
	
}
