package com.db.scv.resource;
/*package com.db.ldv.resource;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.GenericEntity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PathVariable;

import com.db.ldv.model.AccountsByCashGroup;
import com.db.ldv.service.AccountService;

@Path("/groupaccount")
@Component
public class AccountsByCashGroupResource {
	
	private static final Logger LOG = LoggerFactory.getLogger(AccountsByCashGroupResource.class);

	@Autowired
	private AccountService accountService = null;

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/{groupSname}")
	public Response getCashGroupAccounts(@PathVariable("groupSequence")Integer groupSequence) {

		LOG.info(" CashGroupAccounts - groupSequence"+groupSequence+":===:"+groupSequence);
		List<AccountsByCashGroup> cashGroupAccounts=accountService.getCashGroupAccounts(groupSequence);

		LOG.info(" Number of clients accounts fetched -  " + cashGroupAccounts.size());
		GenericEntity<List<AccountsByCashGroup>> ge = new GenericEntity<List<AccountsByCashGroup>>(cashGroupAccounts) {};
		return Response.ok(ge).build();
	}

}
*/