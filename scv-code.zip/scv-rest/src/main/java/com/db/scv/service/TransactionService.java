package com.db.scv.service;

import java.util.List;

import com.db.scv.model.OrderedTransaction;

public interface TransactionService {

	public List<OrderedTransaction> getClientAccountsTransactions(String groupSname);

	public List<OrderedTransaction> getCashGroupAccountsTransactions(String groupSname, Integer groupSequence);

}
