package com.db.scv.resource;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.GenericEntity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.db.scv.model.Product;
import com.db.scv.service.ProductService;

@Path("/product")
@Component
public class ProductResource {
	
	private static final Logger LOG = LoggerFactory.getLogger(ProductResource.class);

	@Autowired
	private ProductService productService = null;

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/client/{groupSname}")
	public Response getClientProducts(@PathParam("groupSname")String groupSname) {
		LOG.info(" Fetching list of clients ");
		List<Product> products = productService.getProductsByClient(groupSname);

		LOG.info(" Number of clients accounts fetched -  " + products.size());
		GenericEntity<List<Product>> ge = new GenericEntity<List<Product>>(products) {};
		return Response.ok(ge).build();
	}
	
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/")
	public Response getAllProducts() {
		LOG.info(" Fetching all products  ");
		List<Product> products = productService.getAllProdcuts();

		LOG.info(" Number of clients accounts fetched -  " + products.size());
		GenericEntity<List<Product>> ge = new GenericEntity<List<Product>>(products) {};
		return Response.ok(ge).build();
	}

}
