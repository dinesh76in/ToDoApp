package com.db.scv.service;

import java.util.List;

import com.db.scv.model.CashGroup;

public interface CashGroupService {

	public List<CashGroup> getClientCashGroups(String groupSname);

	public CashGroup getCashGroupById(Integer groupSequence);
}
