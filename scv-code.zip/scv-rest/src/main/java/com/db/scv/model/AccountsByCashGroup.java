package com.db.scv.model;

public class AccountsByCashGroup {
	
	private String mt940AccId;
	private Integer groupSequence;
	private Integer startDate;
	private Integer endDate;
	private String accRelation;
	private Integer firstTransacDay;
	private Integer lastTransacDay;
	private Integer lastTransac;
	private Integer lastTransacSimul;
	private Integer firstForecast;
	private Integer insertDate;
	private Integer deleteDate;
	private Integer ruleSequence;
	private Integer dataVersionNo;
	private String  changeTimeStamp;
	private String changeUserId;
	private String changeMsgCarrierId;
	private String changeCountry;
	private Integer changeEntity;
	private Integer changeBranch;
	private Integer changeSequence;
	private String flagAlert;
	private String procBranch;
	
	public String getMt940AccId() {
		return mt940AccId;
	}
	public void setMt940AccId(String mt940AccId) {
		this.mt940AccId = mt940AccId;
	}
	public Integer getGroupSequence() {
		return groupSequence;
	}
	public void setGroupSequence(Integer groupSequence) {
		this.groupSequence = groupSequence;
	}
	public Integer getStartDate() {
		return startDate;
	}
	public void setStartDate(Integer startDate) {
		this.startDate = startDate;
	}
	public Integer getEndDate() {
		return endDate;
	}
	public void setEndDate(Integer endDate) {
		this.endDate = endDate;
	}
	public String getAccRelation() {
		return accRelation;
	}
	public void setAccRelation(String accRelation) {
		this.accRelation = accRelation;
	}
	public Integer getFirstTransacDay() {
		return firstTransacDay;
	}
	public void setFirstTransacDay(Integer firstTransacDay) {
		this.firstTransacDay = firstTransacDay;
	}
	public Integer getLastTransacDay() {
		return lastTransacDay;
	}
	public void setLastTransacDay(Integer lastTransacDay) {
		this.lastTransacDay = lastTransacDay;
	}
	public Integer getLastTransac() {
		return lastTransac;
	}
	public void setLastTransac(Integer lastTransac) {
		this.lastTransac = lastTransac;
	}
	public Integer getLastTransacSimul() {
		return lastTransacSimul;
	}
	public void setLastTransacSimul(Integer lastTransacSimul) {
		this.lastTransacSimul = lastTransacSimul;
	}
	public Integer getFirstForecast() {
		return firstForecast;
	}
	public void setFirstForecast(Integer firstForecast) {
		this.firstForecast = firstForecast;
	}
	public Integer getInsertDate() {
		return insertDate;
	}
	public void setInsertDate(Integer insertDate) {
		this.insertDate = insertDate;
	}
	public Integer getDeleteDate() {
		return deleteDate;
	}
	public void setDeleteDate(Integer deleteDate) {
		this.deleteDate = deleteDate;
	}
	public Integer getRuleSequence() {
		return ruleSequence;
	}
	public void setRuleSequence(Integer ruleSequence) {
		this.ruleSequence = ruleSequence;
	}
	public Integer getDataVersionNo() {
		return dataVersionNo;
	}
	public void setDataVersionNo(Integer dataVersionNo) {
		this.dataVersionNo = dataVersionNo;
	}
	public String getChangeTimeStamp() {
		return changeTimeStamp;
	}
	public void setChangeTimeStamp(String changeTimeStamp) {
		this.changeTimeStamp = changeTimeStamp;
	}
	public String getChangeUserId() {
		return changeUserId;
	}
	public void setChangeUserId(String changeUserId) {
		this.changeUserId = changeUserId;
	}
	public String getChangeMsgCarrierId() {
		return changeMsgCarrierId;
	}
	public void setChangeMsgCarrierId(String changeMsgCarrierId) {
		this.changeMsgCarrierId = changeMsgCarrierId;
	}
	public String getChangeCountry() {
		return changeCountry;
	}
	public void setChangeCountry(String changeCountry) {
		this.changeCountry = changeCountry;
	}
	public Integer getChangeEntity() {
		return changeEntity;
	}
	public void setChangeEntity(Integer changeEntity) {
		this.changeEntity = changeEntity;
	}
	public Integer getChangeBranch() {
		return changeBranch;
	}
	public void setChangeBranch(Integer changeBranch) {
		this.changeBranch = changeBranch;
	}
	public Integer getChangeSequence() {
		return changeSequence;
	}
	public void setChangeSequence(Integer changeSequence) {
		this.changeSequence = changeSequence;
	}
	public String getFlagAlert() {
		return flagAlert;
	}
	public void setFlagAlert(String flagAlert) {
		this.flagAlert = flagAlert;
	}
	public String getProcBranch() {
		return procBranch;
	}
	public void setProcBranch(String procBranch) {
		this.procBranch = procBranch;
	}
	
}
