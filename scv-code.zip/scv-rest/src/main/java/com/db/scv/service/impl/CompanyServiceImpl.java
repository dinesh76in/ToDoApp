package com.db.scv.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.db.scv.mapper.cpe.CompanyMapper;
import com.db.scv.model.Company;
import com.db.scv.service.CompanyService;

@Component
@Service
public class CompanyServiceImpl implements CompanyService {

	private static final Logger LOG = LoggerFactory.getLogger(CompanyServiceImpl.class);

	@Autowired
	private CompanyMapper companyMapper = null;
	
	@Override
	public List<Company> getClientCompanies(String groupSname) {
		LOG.info("Fetching legal entities for client "+groupSname);
		return companyMapper.getClientCompanies(groupSname);
	}

	@Override
	public Company getCompany(String cmpnySname) {
		LOG.info("Fetching legal entities details for company "+cmpnySname);
		return companyMapper.getCompany(cmpnySname);
	}
}
