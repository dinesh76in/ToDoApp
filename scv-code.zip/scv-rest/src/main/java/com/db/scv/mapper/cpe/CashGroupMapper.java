package com.db.scv.mapper.cpe;

import java.util.List;

import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.db.scv.model.CashGroup;


public interface CashGroupMapper {


	@Select("Select * from Pz005T where group_sname like '%'||#{groupSname}||'%'")
    @Results(value = {
  	      @Result(property = "groupSequence", column = "GROUP_SEQUENCE"),
  	      @Result(property = "groupSname", column = "GROUP_SNAME"),
  	      @Result(property = "cashGroupSname", column = "CASH_GROUP_SNAME"),
  	      @Result(property = "cashGroupLname", column = "CASH_GROUP_LNAME"),       
  	      @Result(property = "startDate", column = "START_DATE"),
  	      @Result(property = "endDate", column = "END_DATE"),
  	      @Result(property = "cashMeth", column = "CASH_METH"),
  	      @Result(property = "groupOrder", column = "GROUP_ORDER"),
  	      @Result(property = "flagForcedExec", column = "FLAG_FORCED_EXEC"),
  	      @Result(property = "baseCurrency", column = "BASE_CURR"),       
  	      @Result(property = "groupStatus", column = "GROUP_STATUS"),
  	      @Result(property = "futureValues", column = "FUTURE_VALUES"),
  	      @Result(property = "backValuesCredit", column = "BACKVALUES_CREDIT"),
  	      @Result(property = "backValuesDebit", column = "BACKVALUES_DEBIT"),
  	      @Result(property = "flagSimulation", column = "FLAG_SIMULATION"),       
  	      @Result(property = "productionDate", column = "PRODUCTION_DATE"),
  	      @Result(property = "firstSettleDate", column = "FIRST_SETTLE_DATE"),
  	      @Result(property = "insertDate", column = "INSERT_DATE"),       
	      @Result(property = "deleteDate", column = "DELETE_DATE"),
	      @Result(property = "dataVersionNo", column = "DATA_VERSION_NO"),
	      @Result(property = "changeTimestamp", column = "CHANGE_TS"),
	      @Result(property = "changeUserId", column = "CHANGE_USERID"),
	      @Result(property = "changeMsgCarrierId", column = "CHG_MESS_CARR_ID"),   
  	      @Result(property = "changeCountry", column = "CHANGE_COUNTRY"),
  	      @Result(property = "changeEntity", column = "CHANGE_ENTITY"),
  	      @Result(property = "changeBranch", column = "CHANGE_BRANCH"), 
  	      @Result(property = "distributePolicy", column = "DISTRIBUT_POLICY"),
  	      @Result(property = "accountDistribut", column = "ACCOUNT_DISTRIBUT"),
  	      @Result(property = "dayBase", column = "DAY_BASE"),       
  	      @Result(property = "distrPolicyNeg", column = "DISTR_POLICY_NEG"),
  	      @Result(property = "accountDistrNeg", column = "ACCOUNT_DISTR_NEG"),
          @Result(property = "nextSettleDate", column = "NEXT_SETTLE_DATE"),  
	      @Result(property = "continentalType", column = "CONTINENTAL_TYPE"),       
	      @Result(property = "changeSequence", column = "CHANGE_SEQUENCE"),
	      @Result(property = "xgtmFlag", column = "XGTM_FLAG"),
	      @Result(property = "xgtmIdentity", column = "XGTM_IDENTIFY"),
	      @Result(property = "xgtmStartDate", column = "XGTM_START_DATE"),
	      @Result(property = "xgtmEndDate", column = "XGTM_END_DATE"),   
	      @Result(property = "opsTeam", column = "OPS_TEAM"),
	      @Result(property = "procBranch", column = "PROC_BRANCH"),
	      @Result(property = "productSeq", column = "PRODUCT_SEQ"), 	      
	      @Result(property = "processingType", column = "PROCESSING_TYPE")

  	   })
	  public List<CashGroup> getClientCashGroups(String groupSname);
	
	
	@Select("Select * from PZ005T where group_sequence= #{groupSequence}")
    @Results(value = {
  	      @Result(property = "groupSequence", column = "GROUP_SEQUENCE"),
  	      @Result(property = "groupSname", column = "GROUP_SNAME"),
  	      @Result(property = "cashGroupSname", column = "CASH_GROUP_SNAME"),
  	      @Result(property = "cashGroupLname", column = "CASH_GROUP_LNAME"),       
  	      @Result(property = "startDate", column = "START_DATE"),
  	      @Result(property = "endDate", column = "END_DATE"),
  	      @Result(property = "cashMeth", column = "CASH_METH"),
  	      @Result(property = "groupOrder", column = "GROUP_ORDER"),
  	      @Result(property = "flagForcedExec", column = "FLAG_FORCED_EXEC"),
  	      @Result(property = "baseCurrency", column = "BASE_CURR"),       
  	      @Result(property = "groupStatus", column = "GROUP_STATUS"),
  	      @Result(property = "futureValues", column = "FUTURE_VALUES"),
  	      @Result(property = "backValuesCredit", column = "BACKVALUES_CREDIT"),
  	      @Result(property = "backValuesDebit", column = "BACKVALUES_DEBIT"),
  	      @Result(property = "flagSimulation", column = "FLAG_SIMULATION"),       
  	      @Result(property = "productionDate", column = "PRODUCTION_DATE"),
  	      @Result(property = "firstSettleDate", column = "FIRST_SETTLE_DATE"),
  	      @Result(property = "insertDate", column = "INSERT_DATE"),       
	      @Result(property = "deleteDate", column = "DELETE_DATE"),
	      @Result(property = "dataVersionNo", column = "DATA_VERSION_NO"),
	      @Result(property = "changeTimestamp", column = "CHANGE_TS"),
	      @Result(property = "changeUserId", column = "CHANGE_USERID"),
	      @Result(property = "changeMsgCarrierId", column = "CHG_MESS_CARR_ID"),   
  	      @Result(property = "changeCountry", column = "CHANGE_COUNTRY"),
  	      @Result(property = "changeEntity", column = "CHANGE_ENTITY"),
  	      @Result(property = "changeBranch", column = "CHANGE_BRANCH"), 
  	      @Result(property = "distributePolicy", column = "DISTRIBUT_POLICY"),
  	      @Result(property = "accountDistribut", column = "ACCOUNT_DISTRIBUT"),
  	      @Result(property = "dayBase", column = "DAY_BASE"),       
  	      @Result(property = "distrPolicyNeg", column = "DISTR_POLICY_NEG"),
  	      @Result(property = "accountDistrNeg", column = "ACCOUNT_DISTR_NEG"),
          @Result(property = "nextSettleDate", column = "NEXT_SETTLE_DATE"),  
	      @Result(property = "continentalType", column = "CONTINENTAL_TYPE"),       
	      @Result(property = "changeSequence", column = "CHANGE_SEQUENCE"),
	      @Result(property = "xgtmFlag", column = "XGTM_FLAG"),
	      @Result(property = "xgtmIdentity", column = "XGTM_IDENTIFY"),
	      @Result(property = "xgtmStartDate", column = "XGTM_START_DATE"),
	      @Result(property = "xgtmEndDate", column = "XGTM_END_DATE"),   
	      @Result(property = "opsTeam", column = "OPS_TEAM"),
	      @Result(property = "procBranch", column = "PROC_BRANCH"),
	      @Result(property = "productSeq", column = "PRODUCT_SEQ"), 	      
	      @Result(property = "processingType", column = "PROCESSING_TYPE")
  	   })
	  public CashGroup getCashGroupById(Integer groupSequence);
	
}
