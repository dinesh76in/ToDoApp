package com.db.scv.service;

import java.util.List;

import com.db.scv.model.CompanyGroup;

public interface CompanyGroupService {

	public List<CompanyGroup> getCompanyGroups();
	
	public CompanyGroup getCompanyGroup(String groupSname);

}
