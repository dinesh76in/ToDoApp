package com.db.scv.mapper.provider;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class BalanceSelectProvider{
	
	private static final Logger LOG = LoggerFactory.getLogger(BalanceSelectProvider.class);

	
	private static final String COMMA=",";
	private static final String BRACE="'";
	
public String getBalances(Map parameters) {
		
		String []mt940AccIds = (String[]) parameters.get("mt940AccIds");
		Integer execDate = (Integer) parameters.get("execDate");
		Integer fromDate = (Integer) parameters.get("fromDate");
		Integer toDate = (Integer) parameters.get("toDate");
		
		LOG.info("BalanceSelectProvider execDate:fromDate:toDate - "+execDate+":"+fromDate+":"+toDate);
		
		StringBuilder query = new StringBuilder();
		query.append("Select * from PZ019T where MT940_ACC_ID in (");

	    for(String element : mt940AccIds){
	    	query.append( BRACE+element+BRACE+COMMA);
	    }
	    query.delete(query.length()-1, query.length());
	   
	    if(fromDate==0){
	    	 query.append(") and VALUE_DATE ="+execDate+" ");
	    }else{
	    	 query.append(") and VALUE_DATE between "+fromDate+" and "+toDate+" ");
	    }
		
	    LOG.info("Balance Query "+query.toString());
	    
	    
        return query.toString();
	}
}

