package com.db.scv.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.db.scv.mapper.cpe.ProductMapper;
import com.db.scv.model.Product;
import com.db.scv.service.ProductService;

@Component
@Service
public class ProductServicImpl implements ProductService{
	
	private static final Logger LOG = LoggerFactory.getLogger(ProductServicImpl.class);

	@Autowired
	private ProductMapper  productMapper = null;

	@Override
	public List<Product> getProductsByClient(String groupSname) {
		return productMapper.getProductsByClient(groupSname) ;
	}

	@Override
	public List<Product> getAllProdcuts() {
		return productMapper.getAllProducts();
	}

}
