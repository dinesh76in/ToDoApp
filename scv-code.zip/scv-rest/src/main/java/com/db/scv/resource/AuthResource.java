package com.db.scv.resource;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.GenericEntity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.db.scv.model.ScvUser;
import com.db.scv.service.AuthService;

@Path("/auth")
@Component
public class AuthResource {
	
	private static final Logger LOG = LoggerFactory.getLogger(AuthResource.class);

	
	@Autowired
	private AuthService authService = null;
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/user/{userid}/{password}")
	public Response getCashGroupAccountsTransactions(@PathParam("userid")String userid, @PathParam("password")String password) {
		ScvUser user = authService.authenticate(userid, password);

		LOG.info(" ScvUser-  " + user);
		GenericEntity<ScvUser> ge = new GenericEntity<ScvUser>(user) {};
		return Response.ok(ge).build();
	}
	

}
