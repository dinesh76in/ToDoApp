package com.db.scv.service;

import java.util.List;

import com.db.scv.model.Account;

public interface AccountService {
	
	public List<Account> getClientAccounts(String groupSname);
	
	public List<Account> getCompanyAccounts(String groupSname,String cmpnySname);

	public Account getAccountBySequence(Integer accSequence);
	
	public Account getAccountById(String mt940AccId);
	
	public List<Account> getCashGroupAccounts(String groupSname,Integer groupSequence);
}
