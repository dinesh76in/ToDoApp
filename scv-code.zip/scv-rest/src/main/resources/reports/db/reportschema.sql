
drop table Report_Resource;
drop table Report_Param;
drop table Report;

CREATE TABLE Report
( id number(10) NOT NULL,
  name varchar2(50) NOT NULL,
  description varchar2(200),
  type varchar2(50),
  format varchar2(10),
  CONSTRAINT Report_pk PRIMARY KEY (id)
);

CREATE TABLE Report_Param
( id number(10) NOT NULL,
  report_id number(10),
  name varchar2(50),
  description varchar2(200),
  type varchar2(50),
  CONSTRAINT Report_Param_pk PRIMARY KEY (id),
  CONSTRAINT Report_Param_fk FOREIGN KEY (report_id) REFERENCES Report(id)
);

CREATE TABLE Report_Resource
( id number(10) NOT NULL,
  report_id number(10),
  name varchar2(50),
  description varchar2(200),
  type varchar2(50),
  data CLOB,
  CONSTRAINT Report_Resource_pk PRIMARY KEY (id),
  CONSTRAINT Report_Resource_fk FOREIGN KEY (report_id) REFERENCES Report(id)
);

CREATE TABLE Report_Execution
( id number(10) NOT NULL,
  report_id number(10) NOT NULL,
  report_name varchar2(50),
  report_format varchar2(50),
  userid varchar2(50),
  time_start number(10),
  time_end number(10),
  CONSTRAINT Report_Execution_pk PRIMARY KEY (id)
);

CREATE SEQUENCE report_seq   MINVALUE 0   START WITH 1;
