var scvControllers = angular.module('scvControllers', []).constant('baseURL','http://uklonvd824069:8443/scv-rest/');;

scvControllers.controller('CpeHomeCtrl', ['$scope', '$http','baseURL',
    function($scope, $http, baseURL) {
    
    $scope.image ="https://i2.wp.com/www.dhp11.com/foswiki/pub/Internal/2012-06-12/spinner.gif";
     $scope.sort = function(keyname){
     
     console.log(keyname);
        $scope.sortKey = keyname;   //set the sortKey to the param passed
        $scope.reverse = !$scope.reverse; //if true make it false and vice versa
    }
    
    	console.log("getting cpe clients data ");
    	$scope.showSpinner=true;
         $http.get(baseURL+'companygroup').success(function(data) {
            $scope.companygroups = data;
            $scope.showSpinner=false;
        });
    }
]);

scvControllers.controller('DbCoralHomeCtrl', ['$scope', '$http','baseURL',
    function($scope, $http, baseURL) {
    
         $http.get(baseURL+'dbcclient').success(function(data) {
            $scope.dbCoralClientsStaticData = data;
        });

    }
]);

scvControllers.controller('ClientDetailCtrl', ['$scope', '$routeParams', '$http','baseURL',
    function($scope, $routeParams, $http,baseURL) {
        $scope.groupSname = $routeParams.groupSname;
        console.log("getting clients details data ");
        $http.get(baseURL+'companygroup/' + $routeParams.groupSname).success(function(data) {
            $scope.companygroup = data;
            $scope.groupSname = $routeParams.groupSname;
        });
    }
]);

scvControllers.controller('LegalEntitiesCtrl', ['$scope', '$routeParams', '$http','baseURL',
    function($scope, $routeParams, $http,baseURL) {
        $scope.groupSname = $routeParams.groupSname;
        
        $scope.showDetail = function (entity) {
	    if ($scope.active != entity.cmpSname) {
	      $scope.active = entity.cmpSname;
	       $scope.entityDtl=entity;
	    }
	    else {
	      $scope.active = null;
	    }
	  };
	        
          $http.get(baseURL+'company/client/' + $routeParams.groupSname).success(function(data) {
            $scope.legalentities = data;
            $scope.groupSname = $routeParams.groupSname;
        });

    }
]);

scvControllers.controller('AccountsCtrl', ['$scope', '$routeParams', '$http','baseURL',
    function($scope, $routeParams, $http,baseURL) {
        $scope.groupSname = $routeParams.groupSname;
        
         $scope.showDetail = function (acc) {
	    if ($scope.active != acc.mt940AcId) {
	      $scope.active = acc.mt940AcId;
	       $scope.accountDtl=acc;
	    }
	    else {
	      $scope.active = null;
	    }
	  };
	        
        $http.get(baseURL+'account/client/' + $routeParams.groupSname,{ cache: true}).success(function(data) {
            $scope.accounts = data;
            $scope.groupSname = $routeParams.groupSname;
        });


  $scope.toggleDetail = function($index) {
  		 console.log("11");
        //$scope.isVisible = $scope.isVisible == 0 ? true : false;
        $scope.activePosition = $scope.activePosition == $index ? -1 : $index;
    };

    }
]);

scvControllers.controller('CashGroupCtrl', ['$scope', '$routeParams', '$http','baseURL',
    function($scope, $routeParams, $http,baseURL) {
        $scope.groupSname = $routeParams.groupSname;
        
        $scope.showDetail = function (cashgrp) {
	    if ($scope.active != cashgrp.groupSequence) {
	      $scope.active = cashgrp.groupSequence;
	       $scope.cashgrpDtl=cashgrp;
	    }
	    else {
	      $scope.active = null;
	    }
	  };
        
        $http.get(baseURL+'cashgroup/client/' + $routeParams.groupSname).success(function(data) {
            $scope.cashgroups = data;
            $scope.groupSname = $routeParams.groupSname;
        });

    }
]);

scvControllers.controller('EntityAccountsCtrl', ['$scope', '$routeParams', '$http','baseURL',
    function($scope, $routeParams, $http,baseURL) {
        $scope.cmpnySname = $routeParams.cmpnySname;
        
        $scope.showDetail = function (acc) {
	    if ($scope.active != acc.mt940AcId) {
	      $scope.active = acc.mt940AcId;
	       $scope.accountDtl=acc;
	    }
	    else {
	      $scope.active = null;
	    }
	  };
        
     $http.get(baseURL+'account/company/' +$routeParams.groupSname+'/' +$routeParams.cmpnySname).success(function(data) {
            $scope.entityaccounts = data;
            $scope.cmpnySname = $routeParams.cmpnySname;
            $scope.groupSname = $routeParams.groupSname;
        });
    }
]);

scvControllers.controller('CashGroupAccountsCtrl', ['$scope', '$routeParams', '$http','baseURL',
    function($scope, $routeParams, $http,baseURL) {
        $scope.groupSname = $routeParams.groupSname;
        
        $scope.showDetail = function (acc) {
	    if ($scope.active != acc.mt940AcId) {
	      $scope.active = acc.mt940AcId;
	       $scope.accountDtl=acc;
	    }
	    else {
	      $scope.active = null;
	    }
	  };
        
     $http.get(baseURL+'account/cashgroup/'+$routeParams.groupSname+'/' +$routeParams.groupSequence).success(function(data) {
            $scope.cashgroupaccounts = data;
            $scope.cmpnySname = $routeParams.cmpnySname;
            $scope.groupSname = $routeParams.groupSname;
        });
    }
]);

scvControllers.controller('ClientBalancesCtrl', ['$scope', '$routeParams', '$http','baseURL',
    function($scope, $routeParams, $http,baseURL) {
        $scope.groupSname = $routeParams.groupSname;
         $scope.showSpinner=true;
        
        console.log("useTableau");
        console.log($routeParams.useTableau);
        $http.get(baseURL+'balance/' + $routeParams.groupSname + '/'+$routeParams.balanceDate+'/'+$routeParams.action).success(function(data) {
         
         console.log(data[0].valueDate);
         console.log(data[0].execDate);
         
            $scope.clientbalances = data;
            $scope.valueDate = data[0].valueDate;
            $scope.groupSname = $routeParams.groupSname;
            $scope.client=true;
            
              if(data[0].valueDate < data[0].execDate){
		            $scope.enableNextBtn=true;
		        }
		        else{
		           $scope.enableNextBtn=false;
		        }
		     $scope.showSpinner=false;
        });
    }
]);


scvControllers.controller('TableauBalancesCtrl', ['$scope', '$routeParams', '$http','baseURL',
    function($scope, $routeParams, $http,baseURL) {
        $scope.groupSname = $routeParams.groupSname;
        
        console.log("TableauBalancesCtrl - useTableau");
        console.log($routeParams.useTableau);
       
    }
]);


scvControllers.controller('CashGroupBalancesCtrl', ['$scope', '$routeParams', '$http','baseURL',
    function($scope, $routeParams, $http,baseURL) {
        $scope.groupSname = $routeParams.groupSname;
        $http.get(baseURL+'balance/cashgroup/' + $routeParams.groupSname +'/'+$routeParams.groupSequence + '/'+$routeParams.balanceDate+'/'+$routeParams.action).success(function(data) {
            $scope.clientbalances = data;
            $scope.valueDate = data[0].valueDate;
            
            console.log($routeParams.balanceDate);
             console.log(data[0].execDate);
             if(data[0].valueDate < data[0].execDate){
		            $scope.enableNextBtn=true;
		        }
		        else{
		           $scope.enableNextBtn=false;
		        }
            
            
            $scope.groupSname = $routeParams.groupSname;
            $scope.groupSequence = $routeParams.groupSequence;
            $scope.cashGroup=true;
        });
    }
]);

scvControllers.controller('CashGroupRulesCtrl', ['$scope', '$routeParams', '$http','baseURL',
    function($scope, $routeParams, $http,baseURL) {
        $scope.groupSname = $routeParams.groupSname;
        
        
        console.log("CashGroupRulesCtrl");
        
        $scope.showDetail = function (rul) {
	    if ($scope.active != rul.ruleSequence) {
	      $scope.active = rul.ruleSequence;
	       $scope.ruleDtl=rul;
	    }
	    else {
	      $scope.active = null;
	    }
	  };
        
     $http.get(baseURL+'rule/cashgroup/' +$routeParams.groupSequence).success(function(data) {
            $scope.cashgrouprules = data;
            $scope.cmpnySname = $routeParams.cmpnySname;
            $scope.groupSname = $routeParams.groupSname;
        });
    }
]);

scvControllers.controller('CashGroupTransactionsCtrl', ['$scope', '$routeParams', '$http','baseURL',
    function($scope, $routeParams, $http,baseURL) {
        $scope.groupSname = $routeParams.groupSname;
        
        
        console.log("CashGroupTransactionsCtrl");
        
        $scope.showDetail = function (tran) {
	    if ($scope.active != tran.orderIdentifier) {
	      $scope.active = tran.orderIdentifier;
	       $scope.transactionDtl=tran;
	    }
	    else {
	      $scope.active = null;
	    }
	  };
        
     $http.get(baseURL+'transaction/cashgroup/'+ $routeParams.groupSname +'/' +$routeParams.groupSequence).success(function(data) {
            $scope.cashgrouptransactions = data;
            $scope.cmpnySname = $routeParams.cmpnySname;
            $scope.groupSname = $routeParams.groupSname;
        });
    }
]);



scvControllers.controller('ClientProductsCtrl', ['$scope', '$routeParams', '$http','baseURL',
    function($scope, $routeParams, $http,baseURL) {
        $scope.groupSname = $routeParams.groupSname;
        $http.get(baseURL+'product/client/' + $routeParams.groupSname).success(function(data) {
            $scope.products = data;
            $scope.groupSname = $routeParams.groupSname;
          });
    }
]);


scvControllers.controller('ClientReportsCtrl', ['$scope', '$routeParams', '$http','baseURL',
    function($scope, $routeParams, $http,baseURL) {
        $scope.groupSname = $routeParams.groupSname;
        $http.get(baseURL+'report/client/' + $routeParams.groupSname).success(function(data) {
            $scope.reports = data;
            $scope.groupSname = $routeParams.groupSname;
          });
    }
]);


scvControllers.controller('mainController', ['$scope', '$routeParams', '$http','baseURL',
    function($scope, $routeParams,$http,baseURL) {
    	console.log('mainController');
        $scope.groupSname = $routeParams.groupSname;
        $scope.isCollapsed = true;
        console.log($routeParams.accSequence);
         
         $http.get(baseURL+'account/' + $routeParams.accSequence,{ cache: true}).success(function(data) {
            $scope.accountDtl = data;
            $scope.groupSname = $routeParams.groupSname;
        });
        
        $http.get('http://uklonvd824069:8082/scv-rest/account/client/' + $routeParams.groupSname,{ cache: true}).success(function(data) {
        $scope.accounts = data;
        $scope.groupSname = $routeParams.groupSname;
    });
    
    }
]);


