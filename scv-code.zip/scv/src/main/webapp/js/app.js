var scvApp = angular.module('scvApp', [ 'ngRoute', 'scvControllers',
		'ngMaterial', 'angularUtils.directives.dirPagination', 'ngAnimate',
		'ui.bootstrap', 'ngSanitize', 'ngCsv' ]);

scvApp.value("baseURL", "http://uklonvd824069:8082/scv-rest");

scvApp
		.config([
				'$routeProvider',
				function($routeProvider) {
					$routeProvider
							.when('/', {
								templateUrl : 'cpehome.html',
								controller : 'CpeHomeCtrl'
							})
							.when('/home', {
								templateUrl : 'cpehome.html',
								controller : 'CpeHomeCtrl'
							})
							.when('/cpe', {
								templateUrl : 'cpehome.html',
								controller : 'CpeHomeCtrl'
							})
							.when('/dbcoral', {
								templateUrl : 'dbcoralhome.html',
								controller : 'DbCoralHomeCtrl'
							})
							.when('/dashboard/clientdetails/:groupSname', {
								templateUrl : 'party.html',
								controller : 'ClientDetailCtrl'
							})
							.when(
									'/dashboard/legalentities/:groupSname',
									{
										templateUrl : 'includes/viewLegalEntities.html',
										controller : 'LegalEntitiesCtrl'
									})
							.when(
									'/dashboard/account/company/:groupSname/:cmpnySname',
									{
										templateUrl : 'includes/viewEntityAccounts.html',
										controller : 'EntityAccountsCtrl'
									})
							.when('/dashboard/accounts/:groupSname', {
								templateUrl : 'includes/viewAccounts.html',
								controller : 'AccountsCtrl'
							})
							.when(
									'/dashboard/accounts/toggle/:groupSname/:accSequence',
									{
										templateUrl : 'includes/viewAccounts.html',
										controller : 'mainController'
									})
							.when('/dashboard/cashgroups/:groupSname', {
								templateUrl : 'includes/viewCashGroups.html',
								controller : 'CashGroupCtrl'
							})
							.when(
									'/dashboard/cashgroup/accounts/:groupSname/:groupSequence',
									{
										templateUrl : 'includes/viewCashGrpAccounts.html',
										controller : 'CashGroupAccountsCtrl'
									})
							.when(
									'/dashboard/balances/:groupSname/:balanceDate/:action',
									{
										templateUrl : 'includes/viewBalances.html',
										controller : 'ClientBalancesCtrl'
									})
							.when(
									'/dashboard/bal/tableau/:groupSname/:useTableau',
									{
										templateUrl : 'tableaulinks.html',
										controller : 'TableauBalancesCtrl'
									})
							.when(
									'/dashboard/cashgroup/balances/:groupSname/:groupSequence/:balanceDate/:action',
									{
										templateUrl : 'includes/viewBalances.html',
										controller : 'CashGroupBalancesCtrl'
									})
							.when(
									'/dashboard/cashgroup/transactions/:groupSname/:groupSequence',
									{
										templateUrl : 'includes/viewTransactions.html',
										controller : 'CashGroupTransactionsCtrl'
									})
							.when('/dashboard/cashgroup/rules/:groupSname/:groupSequence',{
										templateUrl : 'includes/viewRules.html',
										controller : 'CashGroupRulesCtrl'
							})
							.when('/dashboard/products/:groupSname', {
								templateUrl : 'includes/viewProducts.html',
								controller : 'ClientProductsCtrl'
							}).when('/dashboard/reports/:groupSname', {
								templateUrl : 'includes/reports.html',
								controller : 'ClientReportsCtrl'
							}).when('/clientdetails/:groupSname', {
								templateUrl : 'includes/clientDetails.html',
								controller : 'ClientDetailCtrl'
							}).otherwise({
								redirectTo : '/'
							});
				} ]);
